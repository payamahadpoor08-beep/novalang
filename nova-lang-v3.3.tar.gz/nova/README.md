# Nova

A small, real, **batteries-included programming language** with a hand-written
tree-walking interpreter in Rust, built on a fuzz-tested Pest grammar.

Nova programs actually run and produce output — this is a working language, not
a paper design. It reads clean like Python, but supports structs, closures,
enums with pattern matching, error handling, modules, and an interactive REPL.

```nova
fn fib(n) {
  if n < 2 { n } else { fib(n - 1) + fib(n - 2) }
}

fn main() {
  print(fib(10))        // 55
}
```

---

## Quick start

```bash
cargo build --release

./target/release/nova run program.nova     # run a program
./target/release/nova check program.nova    # parse + type-check, report errors
./target/release/nova test  suite.nova      # run all test "..." { } blocks
./target/release/nova repl                   # interactive REPL
./target/release/nova version                # print version
```

Running `nova` with no arguments drops you straight into the REPL.

---

## Language tour

### Values and variables

`let`, `return`, and semicolons are all **optional**. Write Nova clean like
Python, or explicit like Rust — both styles work and mix freely.

```nova
x = 10                 // no `let` needed
name = "Nova"          // no semicolon needed
greeting = "hello " + name
```

Types: integers, floats, strings, booleans, `null`, arrays, structs, closures,
enums, and maps.

### Operators

```nova
a + b   a - b   a * b   a / b   a % b   a ** b      // arithmetic (** is power)
a == b  a != b  a < b   a <= b  a > b   a >= b      // comparison
a && b  a || b  !a                                   // logic
a ?? b                                               // null-coalescing
```

### Control flow

```nova
if x > 0 { "positive" } else if x < 0 { "negative" } else { "zero" }

while i < 10 { i = i + 1 }

for i in 0..10 { print(i) }      // ranges
for x in array { print(x) }       // iteration

// `if` is an expression — it yields a value
sign = if n < 0 { -1 } else { 1 }
```

### Functions and recursion

```nova
fn factorial(n) {
  if n <= 1 { 1 } else { n * factorial(n - 1) }   // last expression is returned
}
```

### Arrays

```nova
nums = [5, 2, 8, 1, 9]
nums[0] = 99                      // indexed assignment
print(len(nums))
print(sort(nums))                 // [1, 2, 8, 9, 99]
push(nums, 7)
last = pop(nums)
```

### Structs and methods

```nova
struct Account { owner: String, balance: i32 }

impl Account {
  fn deposit(mut self, amount) { self.balance = self.balance + amount }
  fn report(self) { print(self.owner + ": " + str(self.balance)) }
}

fn main() {
  acc = Account { owner: "Payam", balance: 100 }
  acc.deposit(50)
  acc.report()                    // Payam: 150
}
```

Methods take `self` or `mut self`; mutation through `mut self` is visible to the
caller (reference semantics).

### Closures and functional programming

```nova
fn make_adder(n) { x => x + n }   // returns a closure that captures n

nums = [1, 2, 3, 4, 5]
print(map(nums, x => x * 2))             // [2, 4, 6, 8, 10]
print(filter(nums, x => x % 2 == 0))     // [2, 4]
print(reduce(nums, (a, b) => a + b, 0))  // 15

add5 = make_adder(5)
print(add5(10))                          // 15
```

Closures are first-class values with lexical capture: lambdas remember the
environment in which they were created.

### Enums and pattern matching

```nova
enum Option { None, Some(i32) }
enum List   { Nil, Cons(i32, List) }

fn list_sum(lst) {
  match lst {
    Nil => 0,
    Cons(head, tail) => head + list_sum(tail),
  }
}

fn classify(n) {
  match n {
    0 => "zero",
    1 | 2 | 3 => "small",       // or-patterns
    4..=10 => "medium",         // range patterns
    x if x > 100 => "huge",     // guards
    _ => "large",               // wildcard
  }
}
```

Patterns support literals, bindings, enum destructuring, or-patterns, ranges,
guards, and wildcards. Self-referential enums give recursive data types.

### Dictionaries / maps

```nova
freq = dict()
for w in ["apple", "banana", "apple"] {
  if map_has(freq, w) { map_set(freq, w, map_get(freq, w) + 1) }
  else { map_set(freq, w, 1) }
}
print(freq)                       // {"apple": 2, "banana": 1}

ages = dict()
ages["Payam"] = 24                // index syntax works too
print(ages["Payam"])
```

### Error handling

```nova
struct AppError { code: i32, message: String }

fn risky(n) {
  if n < 0 { throw AppError { code: 400, message: "negative" } }
  n * 2
}

fn main() {
  try {
    print(risky(-1))
  } catch err {
    print("error " + str(err.code) + ": " + err.message)
  } finally {
    print("cleanup always runs")
  }
}
```

`throw` raises any value; `try`/`catch`/`finally` handle it. Throws propagate
across function calls to the nearest `try`. Genuine runtime errors and explicit
throws are kept distinct.

### Modules and the standard library

```nova
use math.{sqrt, pow, gcd}
use strings.{upper, split, join}
use arrays.{sort, sum}
use math as m

print(sqrt(2))                    // bare call
print(math.max(5, 9))             // qualified call
print(m.pow(3, 3))                // alias call
```

Standard modules:

- **math**: sqrt, cbrt, pow, abs, floor, ceil, round, trunc, fract, sign, sin, cos, tan, asin, acos, atan, atan2, sinh, cosh, tanh, log, log2, log10, ln, exp, min, max, clamp, lerp, gcd, lcm, factorial, hypot, deg2rad, rad2deg, pi, e, tau, phi
- **strings**: upper, lower, title, capitalize, trim, trim_start, trim_end, split, join, contains, starts_with, ends_with, replace, repeat, pad_left, pad_right, find, substring, levenshtein
- **arrays**: sort, reverse, sum, contains_elem
- **collections**: first, last, min_of, max_of, unique, slice, take, skip, flatten, zip, enumerate, chunk, concat
- **iter**: count, position, all_true, any_true
- **rand**: seed, random, rand_int, rand_float, rand_bool, choice, shuffle
- **time**: now, now_millis, now_nanos
- **json**: json_parse, json_stringify, json_pretty

### Built-in tests

A `test "name" { ... }` block is a first-class language construct. Run them all
with `nova test file.nova`:

```nova
fn factorial(n) { if n <= 1 { 1 } else { n * factorial(n - 1) } }

test "factorial works" {
  assert_eq(factorial(5), 120)
  assert_eq(factorial(0), 1)
}

test "math holds" {
  assert(2 + 2 == 4, "arithmetic broke")
}
```

```
running 2 test(s)

  PASS  factorial works
  PASS  math holds

2 passed, 0 failed
```

### Comprehensions, f-strings, and compound assignment

```nova
// list comprehension: [expr for x in iterable if condition]
squares = [x * x for x in nums]
evens   = [x for x in nums if x % 2 == 0]
both    = [x * 2 for x in nums if x % 2 == 0]

// f-strings: interpolate any expression with { }
name = "Payam"
print(f"Hello {name}, next year you are {age + 1}")

// compound assignment
x += 5    // x = x + 5
x -= 3
x *= 2
x /= 4
x %= 3
```

- comprehensions iterate arrays (and the keys of maps), filter with `if`
- f-strings (`f"...{expr}..."`) interpolate arbitrary expressions
- compound assignment `+= -= *= /= %=` desugars to the binary op

### Infinite loops

```nova
loop {
  if done { break }      // loop runs until an explicit break
  if skip { continue }
}
```

`loop { ... }` is an unconditional loop, equivalent to `while true`. Exit it with
`break` and skip iterations with `continue`.

### Safe navigation and null coalescing

```nova
u?.name              // Null if u is Null, else u.name
u?.profile?.bio      // chains safely through Nulls
config ?? "default"  // value if non-Null, else the fallback
empty?.name ?? "anon"
```

`?.` short-circuits to `null` instead of erroring when the base is `null`.
`??` returns its left side unless it is `null`, in which case it returns the right.

### Bitwise operators and loop control

```nova
print(12 & 10)   // 8   AND
print(12 | 10)   // 14  OR
print(12 ^ 10)   // 6   XOR
print(1 << 4)    // 16  shift left
print(256 >> 2)  // 64  shift right

while true {
  if done { break }       // break exits the loop
  if skip { continue }    // continue skips to the next iteration
}
```

Bitwise `& | ^ << >>` and unary `~` (NOT) work on integers with the usual precedence. Modulo `%` works on both integers and floats (`5.5 % 2.0` is `1.5`). `break` and
`continue` control loop flow in `while`, `for n in a..b`, and `for x in list`.

### Pipelines, maps, sets, and defer

```nova
// pipeline: a |> f desugars to f(a)
result = 5 |> double |> inc       // inc(double(5)) = 11
total  = nums |> filter(even) |> sum

// map literal #{}  and set literal #()
ages = #{"Ali": 30, "Sara": 25}
print(ages["Sara"])                // 25
unique = #(1, 2, 2, 3)             // 3 distinct elements

// defer: runs on the way out, in reverse order, even on throw/return
fn process() {
  defer cleanup()                  // always runs last
  defer print("second")            // runs before cleanup
  work()
}
```

- `|>` threads a value into the next call as its final argument
- `#{k: v, ...}` builds a map; `#(a, b, ...)` builds a set (deduplicated)
- `defer expr` / `defer { ... }` queue work to run when the block exits (LIFO)
- defers run on normal exit, early `return`, and `throw` alike

### Constants and data types

```nova
const MAX_USERS = 100
const APP_NAME = "Nova"
const LIMITS = [10, 20, 30]

data Point(x, y)              // compact struct declaration
data Color(r, g, b)

fn main() {
  print(MAX_USERS * 2)        // 200
  p = Point { x: 3, y: 4 }
  print(p.x)                  // 3
}
```

- `const NAME = value` defines a read-only global, evaluated once at load
- `data Name(a, b, ...)` is a concise struct; construct with `Name { a: .., b: .. }`

### Macros

```nova
macro square { ($x:expr) => { $x * $x } }

fn main() {
  print(square!(5))       // 25
  print(square!(3 + 1))   // 16 — arguments are parenthesised, so precedence holds
}
```

Macros expand at parse time by substituting each argument for its `$param`
placeholder, then re-parsing the result. Arguments are wrapped in parentheses to
preserve evaluation order.

### Generics

Functions and structs can be generic over type parameters. Because Nova's
interpreter is dynamic, generics run with zero overhead; the type checker
understands them too and resolves type variables at each call site.

```nova
fn id[T](x: T) -> T { x }

fn main() {
  print(id(42))        // works with Int
  print(id("hello"))   // and Str, and anything else
}
```

- type parameters go in `[T, U, ...]` after the function or struct name
- the checker substitutes them at call sites: `id[T](x: T) -> T` applied to an
  `Int` argument has return type `Int`, so a later misuse is still caught
- explicit parameter and return types (`n: Int`, `-> Str`) sharpen the checker

### Traits

Traits define a contract of methods that types can implement, with optional
default implementations — like Rust traits or Java interfaces.

```nova
trait Describe {
  fn describe(self) -> Str;          // required (note the semicolon)
  fn loud(self) -> Str { "..." }      // default implementation
}

struct Dog { name: Str }

impl Describe for Dog {
  fn describe(self) -> Str { "a dog named " + self.name }
  fn loud(self) -> Str { "WOOF" }     // overrides the default
}
```

- required methods end with `;`; default methods have a body
- `impl Trait for Type` must provide every required method (checked at load time)
- types inherit default methods they don't override
- calling an unimplemented requirement or an unknown trait is a load-time error

### State machines

A `machine` block is a first-class declarative state machine. It compiles to a
value with a current state plus `send`/`state_of` operations.

```nova
machine TrafficLight {
  initial Red
  Red    -> Green  on "go"
  Green  -> Yellow on "slow"
  Yellow -> Red    on "stop"
}

fn main() {
  light = TrafficLight()
  print(state_of(light))      // Red
  print(send(light, "go"))    // Green
  print(send(light, "slow"))  // Yellow
}
```

- `machine Name { initial S  A -> B on "event" ... }`
- construct with `Name()`, inspect with `state_of(m)`, transition with `send(m, "event")`
- an invalid transition throws, so it can be caught with `try`/`catch`
- `machine`, `initial`, and `on` are contextual — still usable as identifiers

### Interactive REPL

```
$ nova repl
Nova 1.0 — interactive REPL

nova> 1 + 2 * 3
7
nova> x = 10
nova> x * x
100
nova> fn double(n) { n * 2 }
ok
nova> double(21)
42
nova> :quit
```

Definitions and variables persist across lines.

---

## Type checking

`nova check` runs a gradual static type checker before execution. It catches
real mistakes without rejecting valid dynamic code:

```
$ nova check buggy.nova
found 4 type error(s):
  - function `add` expects 2 argument(s), got 1
  - operator `-` requires numbers, found Str and Int
  - if condition must be Bool, found Int
  - undefined variable: unknown_thing
```

It detects undefined variables, wrong function arity, operators on incompatible
types (`"x" - 5`), non-boolean conditions, and unknown struct fields.

The checker infers each function's **return type** and propagates it across call
boundaries, so a bug like `if get_count() { ... }` (where `get_count` returns an
`Int`) is caught even though the error is one call away. It also emits **warnings**
for variables that are assigned but never read (prefix with `_` to silence).

Types that can't be determined become `Unknown`, which unifies with everything —
so the checker complements Nova's dynamic nature instead of fighting it.

## Architecture

```
src/
  nova.pest    the official grammar (v13.1, 539 lines, dot-paths only, no `::`)
               compile-verified against pest 2.7.8; 350k inputs, 0 parser panics
  ast.rs       typed syntax tree
  parser.rs    lowers pest's parse tree into the AST
  types.rs     gradual static type checker (nova check)
  interp.rs    tree-walking interpreter + standard library + test runner
  main.rs      CLI: run / check / test / repl / version
```

The interpreter walks the AST directly, maintaining a call stack of scopes.
Arrays, structs, closures, enums, and maps are reference-counted so mutation
through methods and shared references behaves correctly.

---

## Built-in functions

**Core**: print, len, push, pop, array, str, int, float, abs, sqrt
**Functional**: map, filter, reduce, range
**Maps**: dict, map_set, map_get, map_has, map_del, map_len, map_keys, map_values
**Testing**: assert, assert_eq
**State machines**: send, state_of

(Plus everything in the `math`, `strings`, and `arrays` modules.)

---

### Async, spawn, and channels

Nova runs concurrent code on a cooperative single-threaded scheduler — real
interleaving, no OS threads, no data races.

```nova
async fn compute(n) { n * n }      // calling an async fn yields a Future

fn main() {
  print(compute(8).await)          // 64 — .await drives the Future to a value

  h = spawn { 1 + 2 + 3 }          // spawn queues a task, returns a handle
  print(h.await)                   // 6

  ch = chan()                      // a buffered channel
  spawn {
    ch <- 10                       // send with `ch <- value`
    ch <- 20
    close(ch)
  }
  print(recv(ch) + recv(ch))       // 30 — recv pulls from the channel
}
```

- `async fn f(...)` returns a `Future`; `f(...).await` (or `await f(...)`) runs it
- `spawn { ... }` queues a task and returns a handle; `handle.await` waits for it
- a spawned task's trailing expression is its result value
- channels: `chan()` creates one, `ch <- v` sends, `recv(ch)` receives,
  `close(ch)` closes, `chan_len(ch)` reports buffered count
- tasks that are never awaited still run after `main` returns (fire-and-forget)
- the scheduler advances queued tasks whenever a `recv` would otherwise block,
  so producers and consumers make progress without threads

See `examples/async.nova` for await, spawn, channels, and fan-in together.

## Status

Nova is a working language covering the core of modern programming: functions
and recursion, arrays, structs and methods, closures with capture, enums and
pattern matching, dictionaries, modules with a standard library, error handling,
async/await with spawn and channels, a test runner, and an interactive REPL.

The official grammar (`src/nova.pest`, v13.1) is broader than the interpreter:
it specifies effect polymorphism, linear/affine types, refinement types,
macros 2.0, streams, and `select`. These parse today and are on the roadmap for
execution. Paths use dots only — Nova never uses `::`.


## Slice ranges and static globals (v3.3)

```nova
a = [10, 20, 30, 40, 50]
a[1..3]    // [20, 30]      half-open
a[1..=3]   // [20, 30, 40]  inclusive
a[..2]     // [10, 20]      open start
a[3..]     // [40, 50]      open end
a[-2..]    // [40, 50]      negative index from the end
1..5       // [1, 2, 3, 4]  a range is also a standalone value

static LIMIT = 5             // a global binding (semicolon optional)
```

Slicing works on arrays and strings. A bare `lo..hi` / `lo..=hi` range
materializes into an array. `static` declares a global, like `const`.
