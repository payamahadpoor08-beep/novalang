// A gradual static type checker for Nova. It runs one pass over the AST before
// execution and reports real errors: undefined variables, wrong arity, operators
// applied to incompatible types, non-boolean conditions, and unknown fields.
//
// The checker is deliberately gradual: when a type cannot be determined it
// becomes `Unknown`, which is compatible with everything. This catches genuine
// mistakes without rejecting valid dynamic code that the interpreter accepts.

use crate::ast::*;
use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq)]
pub enum Ty {
    Int,
    Float,
    Str,
    Bool,
    Null,
    Array,
    Map,
    Struct(String),
    Func,
    Unknown,
}

impl Ty {
    fn name(&self) -> String {
        match self {
            Ty::Int => "Int".into(),
            Ty::Float => "Float".into(),
            Ty::Str => "Str".into(),
            Ty::Bool => "Bool".into(),
            Ty::Null => "Null".into(),
            Ty::Array => "Array".into(),
            Ty::Map => "Map".into(),
            Ty::Struct(n) => n.clone(),
            Ty::Func => "Func".into(),
            Ty::Unknown => "Unknown".into(),
        }
    }
    fn is_num(&self) -> bool {
        matches!(self, Ty::Int | Ty::Float | Ty::Unknown)
    }
    // gradual compatibility: Unknown unifies with anything
    fn compatible(&self, other: &Ty) -> bool {
        matches!(self, Ty::Unknown)
            || matches!(other, Ty::Unknown)
            || self == other
            || (self.is_num() && other.is_num())
    }
}

#[derive(Debug, Clone)]
struct FnSig {
    param_types: Vec<Option<String>>,
    ret_type: Option<String>,
    type_params: Vec<String>,
}

pub struct Checker {
    // function name -> parameter count (for arity checks)
    funcs: HashMap<String, usize>,
    // function name -> its signature info (param type heads, return, generics)
    sigs: HashMap<String, FnSig>,
    // function name -> inferred return type
    func_returns: HashMap<String, Ty>,
    // struct/data name -> field names
    structs: HashMap<String, Vec<String>>,
    // known stdlib + builtin function names (arity not enforced, dynamic)
    builtins: Vec<&'static str>,
    // known state-machine names (constructors take no args)
    machines: Vec<String>,
    // global constants -> type
    consts: HashMap<String, Ty>,
    errors: Vec<String>,
    warnings: Vec<String>,
    // identifiers referenced in the current function (for unused-var warnings)
    used: std::collections::HashSet<String>,
}

impl Checker {
    pub fn new(program: &Program) -> Self {
        let mut funcs = HashMap::new();
        let mut sigs = HashMap::new();
        let mut structs = HashMap::new();
        let mut machines = Vec::new();
        let consts = HashMap::new();
        for item in &program.items {
            match item {
                Item::Func(f) => {
                    funcs.insert(f.name.clone(), f.params.len());
                    sigs.insert(f.name.clone(), FnSig {
                        param_types: f.param_types.clone(),
                        ret_type: f.ret_type.clone(),
                        type_params: f.type_params.clone(),
                    });
                }
                Item::Struct(s) => { structs.insert(s.name.clone(), s.fields.clone()); }
                Item::Machine(m) => machines.push(m.name.clone()),
                _ => {}
            }
        }
        Checker {
            funcs,
            sigs,
            func_returns: HashMap::new(),
            structs,
            builtins: builtin_names(),
            machines,
            consts,
            errors: Vec::new(),
            warnings: Vec::new(),
            used: std::collections::HashSet::new(),
        }
    }

    // Check the whole program; returns (type errors, warnings). Empty errors = OK.
    pub fn check(mut self, program: &Program) -> (Vec<String>, Vec<String>) {
        // seed constant types first so functions can reference them
        for item in &program.items {
            if let Item::Const { name, value } = item {
                let mut empty = HashMap::new();
                let t = self.infer(value, &mut empty);
                self.consts.insert(name.clone(), t);
            }
        }
        // PASS 1: infer each function's return type so call sites can use it.
        // Iterate to a fixed point (bounded) so mutually-recursive functions settle.
        for _ in 0..4 {
            let mut changed = false;
            let funcs: Vec<&Func> = program.items.iter().filter_map(|i| match i {
                Item::Func(f) => Some(f),
                _ => None,
            }).collect();
            for f in funcs {
                let rt = self.infer_func_return(f);
                let prev = self.func_returns.get(&f.name).cloned();
                if prev.as_ref() != Some(&rt) {
                    self.func_returns.insert(f.name.clone(), rt);
                    changed = true;
                }
            }
            if !changed { break; }
        }
        // PASS 2: type-check every function/method/test body for real.
        for item in &program.items {
            match item {
                Item::Func(f) => self.check_func(f),
                Item::Impl(imp) => {
                    for m in &imp.methods {
                        self.check_func(m);
                    }
                }
                Item::Test(t) => {
                    let mut scope = HashMap::new();
                    self.check_block(&t.body, &mut scope);
                }
                _ => {}
            }
        }
        (self.errors, self.warnings)
    }


    // Infer a function's return type from its `return` statements and tail value,
    // without emitting errors (that happens in pass 2). Unifies all exit points.
    fn infer_func_return(&mut self, f: &Func) -> Ty {
        // if a concrete return type is declared, trust it
        if let Some(rt) = &f.ret_type {
            if !f.type_params.contains(rt) {
                if let Some(t) = ty_from_name(rt) { return t; }
            }
        }
        let mut scope: HashMap<String, Ty> = HashMap::new();
        scope.insert("self".into(), Ty::Unknown);
        for (i, p) in f.params.iter().enumerate() {
            let ty = f.param_types.get(i).and_then(|o| o.as_ref())
                .and_then(|name| if f.type_params.contains(name) { None } else { ty_from_name(name) })
                .unwrap_or(Ty::Unknown);
            scope.insert(p.clone(), ty);
        }
        let saved_err = self.errors.len();
        let saved_warn = self.warnings.len();
        let mut ret = self.block_return_type(&f.body, &mut scope);
        // an implicit trailing expression is the return value
        if let Some(Stmt::Expr(e)) = f.body.last() {
            let t = self.infer(e, &mut scope);
            ret = unify(ret, t);
        }
        // discard any errors/warnings produced during inference; pass 2 owns those
        self.errors.truncate(saved_err);
        self.warnings.truncate(saved_warn);
        ret
    }

    // Collect the unified type of all `return` statements in a block.
    fn block_return_type(&mut self, stmts: &[Stmt], scope: &mut HashMap<String, Ty>) -> Ty {
        let mut acc = Ty::Unknown;
        let mut seen = false;
        for stmt in stmts {
            match stmt {
                Stmt::Return(Some(e)) => {
                    let t = self.infer(e, scope);
                    acc = if seen { unify(acc, t) } else { t };
                    seen = true;
                }
                Stmt::Return(None) => { acc = if seen { unify(acc, Ty::Null) } else { Ty::Null }; seen = true; }
                Stmt::If { then, els, .. } => {
                    let t1 = self.block_return_type(then, scope);
                    if t1 != Ty::Unknown { acc = if seen { unify(acc, t1.clone()) } else { t1 }; seen = true; }
                    if let Some(e) = els {
                        let t2 = self.block_return_type(e, scope);
                        if t2 != Ty::Unknown { acc = if seen { unify(acc, t2.clone()) } else { t2 }; seen = true; }
                    }
                }
                Stmt::While { body, .. } | Stmt::ForRange { body, .. } | Stmt::ForEach { body, .. } => {
                    let t = self.block_return_type(body, scope);
                    if t != Ty::Unknown { acc = if seen { unify(acc, t.clone()) } else { t }; seen = true; }
                }
                _ => {}
            }
        }
        acc
    }

    fn check_func(&mut self, f: &Func) {
        let mut scope: HashMap<String, Ty> = HashMap::new();
        // `self` is available inside methods; params start Unknown (gradual)
        scope.insert("self".into(), Ty::Unknown);
        for (i, p) in f.params.iter().enumerate() {
            // use the declared type when concrete; generic params stay Unknown
            let ty = f.param_types.get(i).and_then(|o| o.as_ref())
                .and_then(|name| {
                    if f.type_params.contains(name) { None } else { ty_from_name(name) }
                })
                .unwrap_or(Ty::Unknown);
            scope.insert(p.clone(), ty);
        }
        self.used.clear();
        let mut declared: Vec<String> = Vec::new();
        self.collect_declared(&f.body, &mut declared);
        self.check_block(&f.body, &mut scope);
        // warn about let-bound names that are never read (params excluded — they
        // are part of the signature and often intentionally unused)
        for name in &declared {
            if !self.used.contains(name) && !name.starts_with('_') {
                self.warnings.push(format!(
                    "in `{}`: variable `{}` is assigned but never used", f.name, name
                ));
            }
        }
    }

    // Gather names introduced by `let` in a body (descending into nested blocks).
    fn collect_declared(&self, stmts: &[Stmt], out: &mut Vec<String>) {
        for stmt in stmts {
            match stmt {
                Stmt::Let { name, .. } => { if !out.contains(name) { out.push(name.clone()); } }
                Stmt::If { then, els, .. } => {
                    self.collect_declared(then, out);
                    if let Some(e) = els { self.collect_declared(e, out); }
                }
                Stmt::While { body, .. } | Stmt::ForRange { body, .. } | Stmt::ForEach { body, .. } => {
                    self.collect_declared(body, out);
                }
                Stmt::TryCatch { body, catch_body, finally_body, .. } => {
                    self.collect_declared(body, out);
                    if let Some(c) = catch_body { self.collect_declared(c, out); }
                    if let Some(fb) = finally_body { self.collect_declared(fb, out); }
                }
                _ => {}
            }
        }
    }

    fn check_block(&mut self, stmts: &[Stmt], scope: &mut HashMap<String, Ty>) {
        for stmt in stmts {
            self.check_stmt(stmt, scope);
        }
    }

    fn check_stmt(&mut self, stmt: &Stmt, scope: &mut HashMap<String, Ty>) {
        match stmt {
            Stmt::Let { name, value } | Stmt::Assign { name, value } => {
                let t = self.infer(value, scope);
                scope.insert(name.clone(), t);
            }
            Stmt::IndexAssign { base, index, value } => {
                self.infer(base, scope);
                self.infer(index, scope);
                self.infer(value, scope);
            }
            Stmt::FieldAssign { base, value, .. } => {
                self.infer(base, scope);
                self.infer(value, scope);
            }
            Stmt::Expr(e) => { self.infer(e, scope); }
            Stmt::Return(Some(e)) => { self.infer(e, scope); }
            Stmt::Return(None) => {}
            Stmt::Throw(e) => { self.infer(e, scope); }
            Stmt::Break(Some(e)) => { self.infer(e, scope); }
            Stmt::Break(None) | Stmt::Continue => {}
            Stmt::If { cond, then, els } => {
                let ct = self.infer(cond, scope);
                self.expect_bool(&ct, "if condition");
                let mut s1 = scope.clone();
                self.check_block(then, &mut s1);
                if let Some(e) = els {
                    let mut s2 = scope.clone();
                    self.check_block(e, &mut s2);
                }
            }
            Stmt::While { cond, body } => {
                let ct = self.infer(cond, scope);
                self.expect_bool(&ct, "while condition");
                let mut s = scope.clone();
                self.check_block(body, &mut s);
            }
            Stmt::ForRange { var, start, end, body, .. } => {
                let st = self.infer(start, scope);
                let et = self.infer(end, scope);
                if !st.is_num() { self.err(format!("for-range start must be a number, found {}", st.name())); }
                if !et.is_num() { self.err(format!("for-range end must be a number, found {}", et.name())); }
                let mut s = scope.clone();
                s.insert(var.clone(), Ty::Int);
                self.check_block(body, &mut s);
            }
            Stmt::ForEach { var, iter, body } => {
                self.infer(iter, scope);
                let mut s = scope.clone();
                s.insert(var.clone(), Ty::Unknown);
                self.check_block(body, &mut s);
            }
            Stmt::Defer(body) => {
                let mut s = scope.clone();
                self.check_block(body, &mut s);
            }
            Stmt::TryCatch { body, catch_var, catch_body, finally_body } => {
                let mut s1 = scope.clone();
                self.check_block(body, &mut s1);
                if let Some(cb) = catch_body {
                    let mut s2 = scope.clone();
                    if let Some(v) = catch_var { s2.insert(v.clone(), Ty::Unknown); }
                    self.check_block(cb, &mut s2);
                }
                if let Some(fb) = finally_body {
                    let mut s3 = scope.clone();
                    self.check_block(fb, &mut s3);
                }
            }
        }
    }

    fn infer(&mut self, e: &Expr, scope: &mut HashMap<String, Ty>) -> Ty {
        match e {
            Expr::Int(_) => Ty::Int,
            Expr::BigIntLit(_) => Ty::Int,
            Expr::Float(_) => Ty::Float,
            Expr::Str(_) => Ty::Str,
            Expr::Bool(_) => Ty::Bool,
            Expr::Null => Ty::Null,
            Expr::FmtStr(parts) => {
                for p in parts {
                    if let FmtPart::Expr(ex) = p { self.infer(ex, scope); }
                }
                Ty::Str
            }
            Expr::Array(items) => {
                for it in items { self.infer(it, scope); }
                Ty::Array
            }
            Expr::MapLit(entries) => {
                for (k, v) in entries { self.infer(k, scope); self.infer(v, scope); }
                Ty::Map
            }
            Expr::SetLit(items) => {
                for it in items { self.infer(it, scope); }
                Ty::Map
            }
            Expr::Comprehension { body, var, iter, cond } => {
                self.infer(iter, scope);
                let mut s = scope.clone();
                s.insert(var.clone(), Ty::Unknown);
                if let Some(c) = cond { self.infer(c, &mut s); }
                self.infer(body, &mut s);
                Ty::Array
            }
            Expr::Ident(name) => {
                self.used.insert(name.clone());
                if let Some(t) = scope.get(name) { return t.clone(); }
                if let Some(t) = self.consts.get(name) { return t.clone(); }
                // a bare function name used as a value, or a unit enum variant
                if self.funcs.contains_key(name) || self.builtins.contains(&name.as_str()) {
                    return Ty::Func;
                }
                // unit enum variants (None, Nil, etc.) start with uppercase — be lenient
                if name.chars().next().map_or(false, |c| c.is_uppercase()) {
                    return Ty::Unknown;
                }
                // names starting with `_` are context-injected or intentionally
                // special (e.g. `_recv` inside a select arm) — don't flag them
                if name.starts_with('_') {
                    return Ty::Unknown;
                }
                self.err(format!("undefined variable: {}", name));
                Ty::Unknown
            }
            Expr::Index { base, index } => {
                let bt = self.infer(base, scope);
                // a[lo..hi] slices: result type matches the base collection
                if let Expr::RangeLit { lo, hi, .. } = &**index {
                    if let Some(e) = lo { self.infer(e, scope); }
                    if let Some(e) = hi { self.infer(e, scope); }
                    return match bt { Ty::Array => Ty::Array, Ty::Str => Ty::Str, _ => Ty::Unknown };
                }
                self.infer(index, scope);
                Ty::Unknown
            }
            Expr::RangeLit { lo, hi, .. } => {
                if let Some(e) = lo { self.infer(e, scope); }
                if let Some(e) = hi { self.infer(e, scope); }
                Ty::Array
            }
            Expr::StructLit { name, fields } => {
                if let Some(decl_fields) = self.structs.get(name).cloned() {
                    for (fname, fexpr) in fields {
                        self.infer(fexpr, scope);
                        if !decl_fields.contains(fname) {
                            self.err(format!("struct {} has no field `{}`", name, fname));
                        }
                    }
                } else {
                    for (_, fexpr) in fields { self.infer(fexpr, scope); }
                }
                Ty::Struct(name.clone())
            }
            Expr::Field { base, field } => {
                let bt = self.infer(base, scope);
                if let Ty::Struct(sname) = &bt {
                    if let Some(decl) = self.structs.get(sname) {
                        if !decl.contains(field) && field != "state" {
                            self.err(format!("struct {} has no field `{}`", sname, field));
                        }
                    }
                }
                Ty::Unknown
            }
            Expr::SafeField { base, .. } => {
                self.infer(base, scope);
                Ty::Unknown
            }
            Expr::MethodCall { base, args, .. } => {
                self.infer(base, scope);
                for a in args { self.infer(a, scope); }
                Ty::Unknown
            }
            Expr::Lambda { params, body } => {
                let mut s = scope.clone();
                for p in params { s.insert(p.clone(), Ty::Unknown); }
                match &**body {
                    LambdaBody::Expr(e) => { self.infer(e, &mut s); }
                    LambdaBody::Block(stmts) => { self.check_block(stmts, &mut s); }
                }
                Ty::Func
            }
            Expr::CallValue { callee, args } => {
                self.infer(callee, scope);
                for a in args { self.infer(a, scope); }
                Ty::Unknown
            }
            Expr::Unary { op, expr } => {
                let t = self.infer(expr, scope);
                match op {
                    UnOp::Neg => {
                        if !t.is_num() { self.err(format!("cannot negate {}", t.name())); }
                        t
                    }
                    UnOp::Not => Ty::Bool,
                    UnOp::BitNot => {
                        if !t.is_num() { self.err(format!("cannot apply `~` to {}", t.name())); }
                        Ty::Int
                    }
                }
            }
            Expr::Binary { op, lhs, rhs } => {
                let lt = self.infer(lhs, scope);
                let rt = self.infer(rhs, scope);
                self.check_binop(*op, &lt, &rt)
            }
            Expr::Call { callee, args } => {
                for a in args { self.infer(a, scope); }
                // arity check for user functions (builtins are dynamic)
                if let Some(arity) = self.funcs.get(callee).copied() {
                    if arity != args.len() {
                        self.err(format!(
                            "function `{}` expects {} argument(s), got {}",
                            callee, arity, args.len()
                        ));
                    }
                    // generic substitution: if the return type names a generic
                    // parameter (e.g. `-> T`), resolve it from the argument bound
                    // to that same parameter. e.g. id[T](x: T) -> T applied to Int
                    // yields Int.
                    if let Some(sig) = self.sigs.get(callee).cloned() {
                        if let Some(ret) = &sig.ret_type {
                            if sig.type_params.contains(ret) {
                                // find a parameter whose declared type is this generic
                                for (i, pt) in sig.param_types.iter().enumerate() {
                                    if pt.as_deref() == Some(ret.as_str()) {
                                        if let Some(arg) = args.get(i) {
                                            return self.infer(arg, scope);
                                        }
                                    }
                                }
                            } else if let Some(concrete) = ty_from_name(ret) {
                                // a concrete declared return type
                                return concrete;
                            }
                        }
                    }
                    // otherwise fall back to the inferred return type
                    return self.func_returns.get(callee).cloned().unwrap_or(Ty::Unknown);
                }
                if self.machines.contains(callee) {
                    return Ty::Struct(callee.clone());
                }
                if self.structs.contains_key(callee) {
                    return Ty::Struct(callee.clone());
                }
                // enum variant constructor or stdlib: lenient
                Ty::Unknown
            }
            Expr::Block { stmts, tail } => {
                let mut s = scope.clone();
                self.check_block(stmts, &mut s);
                match tail {
                    Some(e) => self.infer(e, &mut s),
                    None => Ty::Null,
                }
            }
            Expr::If { cond, then, els } => {
                let ct = self.infer(cond, scope);
                self.expect_bool(&ct, "if expression condition");
                let tt = self.infer(then, scope);
                let et = self.infer(els, scope);
                if tt.compatible(&et) { tt } else { Ty::Unknown }
            }
            Expr::Match { scrutinee, arms } => {
                self.infer(scrutinee, scope);
                for arm in arms {
                    let mut s = scope.clone();
                    bind_pattern(&arm.pattern, &mut s);
                    if let Some(g) = &arm.guard { self.infer(g, &mut s); }
                    self.infer(&arm.body, &mut s);
                }
                Ty::Unknown
            }
            // --- async / concurrency ---
            // The gradual checker doesn't model Future/Task/Channel types yet,
            // so it walks their sub-expressions (to catch ordinary errors inside)
            // and yields Unknown, which unifies with everything.
            Expr::Await(inner) => {
                self.infer(inner, scope);
                Ty::Unknown
            }
            Expr::Spawn(stmts) => {
                let mut s = scope.clone();
                self.check_block(stmts, &mut s);
                Ty::Unknown
            }
            Expr::Recv(chan) => {
                self.infer(chan, scope);
                Ty::Unknown
            }
            Expr::Send { chan, value } => {
                self.infer(chan, scope);
                self.infer(value, scope);
                Ty::Null
            }
            Expr::Select(arms) => {
                for arm in arms {
                    self.infer(&arm.chan, scope);
                    let mut s = scope.clone();
                    if let Some(name) = &arm.binding {
                        s.insert(name.clone(), Ty::Unknown);
                    }
                    self.infer(&arm.body, &mut s);
                }
                Ty::Unknown
            }
        }
    }

    fn check_binop(&mut self, op: BinOp, lt: &Ty, rt: &Ty) -> Ty {
        use BinOp::*;
        match op {
            Add => {
                // + works on numbers and on strings (concat); arrays too in Nova
                if matches!(lt, Ty::Str) || matches!(rt, Ty::Str) { return Ty::Str; }
                if lt.is_num() && rt.is_num() {
                    return if *lt == Ty::Float || *rt == Ty::Float { Ty::Float } else { Ty::Int };
                }
                if matches!(lt, Ty::Unknown) || matches!(rt, Ty::Unknown) { return Ty::Unknown; }
                if matches!(lt, Ty::Array) && matches!(rt, Ty::Array) { return Ty::Array; }
                self.err(format!("cannot apply `+` to {} and {}", lt.name(), rt.name()));
                Ty::Unknown
            }
            Sub | Mul | Div | Rem | Pow => {
                if !lt.is_num() || !rt.is_num() {
                    self.err(format!("operator `{}` requires numbers, found {} and {}",
                        binop_sym(op), lt.name(), rt.name()));
                    return Ty::Unknown;
                }
                if *lt == Ty::Float || *rt == Ty::Float || matches!(op, Div | Pow) { Ty::Float } else { Ty::Int }
            }
            Eq | Ne => Ty::Bool,
            Lt | Le | Gt | Ge => {
                if !lt.compatible(rt) {
                    self.err(format!("cannot compare {} with {}", lt.name(), rt.name()));
                }
                Ty::Bool
            }
            And | Or => Ty::Bool,
            BitOr | BitXor | BitAnd | Shl | Shr => {
                if !lt.is_num() || !rt.is_num() {
                    self.err(format!("bitwise operator requires integers, found {} and {}", lt.name(), rt.name()));
                }
                Ty::Int
            }
        }
    }

    fn expect_bool(&mut self, t: &Ty, ctx: &str) {
        // gradual: Unknown is fine; only flag a definitely-wrong type
        if !matches!(t, Ty::Bool | Ty::Unknown) {
            self.err(format!("{} must be Bool, found {}", ctx, t.name()));
        }
    }

    fn err(&mut self, msg: String) {
        self.errors.push(msg);
    }
}

// Merge two types at a control-flow join point. Identical types stay; numbers
// widen to a common numeric type; anything else (or Unknown) yields Unknown.
// Map a declared type name to a checker Ty. Unknown for type variables / unknown.
fn ty_from_name(name: &str) -> Option<Ty> {
    Some(match name {
        "Int" | "i8" | "i16" | "i32" | "i64" | "u8" | "u16" | "u32" | "u64" => Ty::Int,
        "Float" | "f32" | "f64" => Ty::Float,
        "Str" | "String" => Ty::Str,
        "Bool" => Ty::Bool,
        "Null" => Ty::Null,
        "Array" | "List" | "Vec" => Ty::Array,
        "Map" | "Dict" => Ty::Map,
        _ => return None,
    })
}

fn unify(a: Ty, b: Ty) -> Ty {
    if a == b { return a; }
    match (&a, &b) {
        (Ty::Unknown, _) | (_, Ty::Unknown) => Ty::Unknown,
        (Ty::Int, Ty::Float) | (Ty::Float, Ty::Int) => Ty::Float,
        _ => Ty::Unknown,
    }
}

fn binop_sym(op: BinOp) -> &'static str {
    use BinOp::*;
    match op {
        Add => "+", Sub => "-", Mul => "*", Div => "/", Rem => "%", Pow => "**",
        Eq => "==", Ne => "!=", Lt => "<", Le => "<=", Gt => ">", Ge => ">=",
        And => "&&", Or => "||",
        BitOr => "|", BitXor => "^", BitAnd => "&", Shl => "<<", Shr => ">>",
    }
}

// Bind the variables a pattern introduces (as Unknown) so the arm body can use them.
fn bind_pattern(p: &Pattern, scope: &mut HashMap<String, Ty>) {
    match p {
        Pattern::Binding(name) => { scope.insert(name.clone(), Ty::Unknown); }
        Pattern::EnumVariant { sub, .. } => {
            for b in sub { bind_pattern(b, scope); }
        }
        Pattern::Or(ps) => { for x in ps { bind_pattern(x, scope); } }
        Pattern::Tuple(ps) => { for x in ps { bind_pattern(x, scope); } }
        Pattern::Struct { fields, .. } => {
            for (_, sub) in fields { bind_pattern(sub, scope); }
        }
        _ => {}
    }
}

fn builtin_names() -> Vec<&'static str> {
    vec![
        "print", "len", "push", "pop", "array", "str", "int", "float", "abs", "sqrt",
        "map", "filter", "reduce", "range", "dict", "map_set", "map_get", "map_has",
        "map_del", "map_len", "map_keys", "map_values", "assert", "assert_eq",
        "send", "state_of", "type_of",
    ]
}
