mod ast;
mod parser;
mod interp;
mod types;

use std::io::{self, Write, BufRead};
use std::process::exit;

const VERSION: &str = "1.0";

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 2 {
        repl();
        return;
    }

    match args[1].as_str() {
        "run" => {
            let path = require_path(&args);
            let src = read(&path);
            let program = match parser::parse_program(&src) {
                Ok(p) => p,
                Err(e) => { eprintln!("{}", e); exit(1); }
            };
            let interp = match interp::Interp::new(&program) {
                Ok(i) => i,
                Err(e) => { eprintln!("error: {}", e); exit(1); }
            };
            match interp.run() {
                Ok(_) => {}
                Err(e) => { eprintln!("runtime error: {}", e); exit(1); }
            }
        }
        "check" => {
            let path = require_path(&args);
            let src = read(&path);
            match parser::parse_program(&src) {
                Ok(p) => {
                    let (errors, warnings) = types::Checker::new(&p).check(&p);
                    for w in &warnings {
                        eprintln!("warning: {}", w);
                    }
                    if errors.is_empty() {
                        println!("OK: parsed {} item(s), no type errors", p.items.len());
                    } else {
                        eprintln!("found {} type error(s):", errors.len());
                        for e in &errors {
                            eprintln!("  - {}", e);
                        }
                        exit(1);
                    }
                }
                Err(e) => { eprintln!("{}", e); exit(1); }
            }
        }
        "repl" => repl(),
        "test" => {
            let path = require_path(&args);
            let src = read(&path);
            let program = match parser::parse_program(&src) {
                Ok(p) => p,
                Err(e) => { eprintln!("{}", e); exit(1); }
            };
            let interp = match interp::Interp::new(&program) {
                Ok(i) => i,
                Err(e) => { eprintln!("error: {}", e); exit(1); }
            };
            let failures = interp.run_tests();
            if failures > 0 { exit(1); }
        }
        "version" | "--version" | "-v" => println!("Nova {}", VERSION),
        other => {
            eprintln!("unknown command: {}", other);
            eprintln!("usage: nova [run <file> | check <file> | repl | version]");
            exit(2);
        }
    }
}

fn repl() {
    println!("Nova {} — interactive REPL", VERSION);
    println!("Type expressions or definitions. Commands: :help  :quit\n");

    // An empty program seeds an interpreter; the REPL grows its tables over time.
    let empty = ast::Program { items: Vec::new() };
    let mut interp = match interp::Interp::new(&empty) {
        Ok(i) => i,
        Err(e) => { eprintln!("init error: {}", e); exit(1); }
    };
    let mut scope = interp::Scope::new();

    let stdin = io::stdin();
    let mut lines = stdin.lock().lines();
    loop {
        print!("nova> ");
        io::stdout().flush().ok();
        let line = match lines.next() {
            Some(Ok(l)) => l,
            _ => { println!("\nbye!"); break; }
        };
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        match trimmed {
            ":quit" | ":q" | ":exit" => { println!("bye!"); break; }
            ":help" | ":h" => {
                println!("  type any Nova expression to evaluate it");
                println!("  define functions/structs/enums and they persist");
                println!("  :quit  exit    :help  this message");
                continue;
            }
            _ => {}
        }
        match parser::parse_repl(&line) {
            Ok((prog, stmts)) => {
                if !prog.items.is_empty() {
                    if let Err(e) = interp.register_items(&prog) {
                        println!("error: {}", e);
                        continue;
                    }
                    println!("ok");
                } else {
                    match interp.eval_repl(&stmts, &mut scope) {
                        Ok(Some(v)) => {
                            if !matches!(v, interp::Value::Null) {
                                println!("{}", v);
                            }
                        }
                        Ok(None) => {}
                        Err(e) => println!("error: {}", e),
                    }
                }
            }
            Err(e) => println!("{}", e.lines().last().unwrap_or("parse error")),
        }
    }
}

fn require_path(args: &[String]) -> String {
    if args.len() < 3 {
        eprintln!("error: missing file path");
        exit(2);
    }
    args[2].clone()
}

fn read(path: &str) -> String {
    match std::fs::read_to_string(path) {
        Ok(s) => s,
        Err(e) => { eprintln!("error: cannot read {}: {}", path, e); exit(1); }
    }
}
