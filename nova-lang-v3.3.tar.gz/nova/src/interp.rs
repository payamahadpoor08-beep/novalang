// Tree-walking interpreter for Nova Core.
// Walks the AST directly, maintaining a call stack of scopes.

use std::collections::HashMap;
use std::cell::RefCell;
use std::rc::Rc;
use std::fmt;
use num_bigint::BigInt;
use num_traits::{ToPrimitive, Zero, Signed};

use crate::ast::*;

pub type Scope = HashMap<String, Value>;

// Internal marker: an Err carrying this string means "a Nova `throw` is unwinding";
// the real thrown Value lives in Interp::pending_throw. Distinguishes user throws
// from genuine runtime errors so try/catch only catches the former.
const THROW_SENTINEL: &str = "\u{0}__nova_throw__";

thread_local! {
    // xorshift64* RNG state for the `rand` module. Seeded from the wall clock on
    // first use; reseedable via rand.seed(n) for reproducible runs.
    static RNG_STATE: RefCell<u64> = RefCell::new(0);
}

fn rng_seed_from_clock() -> u64 {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0x9E3779B97F4A7C15);
    nanos ^ 0x2545F4914F6CDD1D
}

fn rng_next() -> u64 {
    RNG_STATE.with(|s| {
        let mut x = *s.borrow();
        if x == 0 { x = rng_seed_from_clock(); }
        // xorshift64*
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        *s.borrow_mut() = x;
        x.wrapping_mul(0x2545F4914F6CDD1D)
    })
}

fn rng_seed(n: u64) {
    RNG_STATE.with(|s| *s.borrow_mut() = if n == 0 { 1 } else { n });
}

// uniform float in [0, 1)
fn rng_float() -> f64 {
    (rng_next() >> 11) as f64 / (1u64 << 53) as f64
}

#[derive(Debug, Clone)]
pub enum Value {
    Int(i64),
    BigInt(num_bigint::BigInt),
    Float(f64),
    Str(String),
    Bool(bool),
    Null,
    Array(Rc<RefCell<Vec<Value>>>),
    Struct(Rc<RefCell<StructInstance>>),
    Closure(Rc<ClosureVal>),
    Enum(Rc<EnumVal>),
    Map(Rc<RefCell<Vec<(Value, Value)>>>),
    // A lazy async computation: holds the body + captured scope until awaited.
    Future(Rc<RefCell<FutureVal>>),
    // A handle to a spawned task; awaiting it drives the scheduler until done.
    Task(Rc<RefCell<TaskVal>>),
    // A buffered channel for passing values between tasks.
    Channel(Rc<RefCell<ChannelVal>>),
}

// State of an async-fn future. Created Pending; awaiting runs the body once
// and caches the result, so a future can be awaited at most meaningfully once.
#[derive(Debug, Clone)]
pub enum FutureState {
    Pending,
    Running,   // guards against awaiting a future from within itself
    Done(Value),
    Failed(Value), // a throw escaped the future body
}

pub struct FutureVal {
    pub body: Vec<Stmt>,
    pub scope: Scope,
    pub state: FutureState,
}

impl std::fmt::Debug for FutureVal {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "FutureVal({:?})", self.state)
    }
}

// A spawned task. Like a future but identified for the scheduler queue.
#[derive(Debug)]
pub struct TaskVal {
    pub id: u64,
    pub state: FutureState,
}

impl TaskVal {
    fn state_clone(&self) -> FutureState {
        self.state.clone()
    }
}

// A buffered FIFO channel. `closed` lets receivers learn the sender is gone.
#[derive(Debug)]
pub struct ChannelVal {
    pub buffer: std::collections::VecDeque<Value>,
    pub capacity: usize, // 0 means unbounded
    pub closed: bool,
}

#[derive(Debug)]
pub struct EnumVal {
    pub enum_name: String,
    pub variant: String,
    pub data: Vec<Value>,
}

#[derive(Debug)]
pub struct ClosureVal {
    pub params: Vec<String>,
    pub body: LambdaBody,
    // captured environment: a snapshot of the defining scope
    pub captured: Scope,
}

#[derive(Debug, Clone)]
pub struct StructInstance {
    pub type_name: String,
    pub fields: HashMap<String, Value>,
}

impl PartialEq for Value {
    fn eq(&self, other: &Self) -> bool {
        values_eq(self, other)
    }
}

// Normalize a BigInt back to a machine Int when it fits, keeping the fast path hot.
fn norm_big(b: BigInt) -> Value {
    match b.to_i64() {
        Some(n) => Value::Int(n),
        None => Value::BigInt(b),
    }
}

// View any integer value as a BigInt for mixed arithmetic.
fn as_big(v: &Value) -> Option<BigInt> {
    match v {
        Value::Int(n) => Some(BigInt::from(*n)),
        Value::BigInt(b) => Some(b.clone()),
        _ => None,
    }
}

impl fmt::Display for Value {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Value::Int(n) => write!(f, "{}", n),
            Value::BigInt(b) => write!(f, "{}", b),
            Value::Float(x) => {
                if x.fract() == 0.0 && x.is_finite() {
                    write!(f, "{:.1}", x)
                } else {
                    write!(f, "{}", x)
                }
            }
            Value::Str(s) => write!(f, "{}", s),
            Value::Bool(b) => write!(f, "{}", b),
            Value::Null => write!(f, "null"),
            Value::Array(items) => {
                let inner = items.borrow();
                let parts: Vec<String> = inner.iter().map(|v| match v {
                    Value::Str(s) => format!("\"{}\"", s),
                    other => other.to_string(),
                }).collect();
                write!(f, "[{}]", parts.join(", "))
            }
            Value::Struct(inst) => {
                let inst = inst.borrow();
                // Print fields in a stable order isn't guaranteed by HashMap; sort for readability.
                let mut keys: Vec<&String> = inst.fields.keys().collect();
                keys.sort();
                let parts: Vec<String> = keys.iter().map(|k| {
                    let v = &inst.fields[*k];
                    let vs = match v {
                        Value::Str(s) => format!("\"{}\"", s),
                        other => other.to_string(),
                    };
                    format!("{}: {}", k, vs)
                }).collect();
                write!(f, "{} {{ {} }}", inst.type_name, parts.join(", "))
            }
            Value::Closure(c) => write!(f, "<closure/{}>", c.params.len()),
            Value::Enum(e) => {
                if e.data.is_empty() {
                    write!(f, "{}", e.variant)
                } else {
                    let parts: Vec<String> = e.data.iter().map(|v| match v {
                        Value::Str(s) => format!("\"{}\"", s),
                        other => other.to_string(),
                    }).collect();
                    write!(f, "{}({})", e.variant, parts.join(", "))
                }
            }
            Value::Map(m) => {
                let inner = m.borrow();
                let parts: Vec<String> = inner.iter().map(|(k, v)| {
                    let ks = match k {
                        Value::Str(s) => format!("\"{}\"", s),
                        other => other.to_string(),
                    };
                    let vs = match v {
                        Value::Str(s) => format!("\"{}\"", s),
                        other => other.to_string(),
                    };
                    format!("{}: {}", ks, vs)
                }).collect();
                write!(f, "{{{}}}", parts.join(", "))
            }
            Value::Future(fut) => {
                match &fut.borrow().state {
                    FutureState::Done(v) => write!(f, "<future={}>", v),
                    FutureState::Failed(_) => write!(f, "<future:failed>"),
                    _ => write!(f, "<future:pending>"),
                }
            }
            Value::Task(t) => write!(f, "<task#{}>", t.borrow().id),
            Value::Channel(ch) => {
                let c = ch.borrow();
                write!(f, "<channel:{} buffered>", c.buffer.len())
            }
        }
    }
}

impl Value {
    fn type_name(&self) -> &'static str {
        match self {
            Value::Int(_) => "int",
            Value::BigInt(_) => "int",
            Value::Float(_) => "float",
            Value::Str(_) => "string",
            Value::Bool(_) => "bool",
            Value::Null => "null",
            Value::Array(_) => "array",
            Value::Struct(_) => "struct",
            Value::Closure(_) => "closure",
            Value::Enum(_) => "enum",
            Value::Map(_) => "map",
            Value::Future(_) => "future",
            Value::Task(_) => "task",
            Value::Channel(_) => "channel",
        }
    }
    fn is_truthy(&self) -> bool {
        match self {
            Value::Bool(b) => *b,
            Value::Null => false,
            Value::Int(n) => *n != 0,
            Value::BigInt(b) => !b.is_zero(),
            _ => true,
        }
    }
}

// Control-flow signal used to unwind out of a function on `return`.
enum Flow {
    Normal,
    Return(Value),
    Throw(Value),
    Break(Value),
    Continue,
}

pub struct Interp {
    funcs: HashMap<String, Func>,
    structs: HashMap<String, StructDef>,
    // methods keyed by (type_name, method_name)
    methods: HashMap<(String, String), Func>,
    // variant_name -> (enum_name, arity)
    variants: HashMap<String, (String, usize)>,
    // module alias -> real module root (e.g. "m" -> "math")
    module_aliases: HashMap<String, String>,
    // carries a thrown value across function-call boundaries
    pending_throw: RefCell<Option<Value>>,
    // collected test blocks, in source order
    tests: Vec<crate::ast::TestBlock>,
    // state machines: name -> (initial_state, transitions[(from,to,event)])
    machines: HashMap<String, (String, Vec<(String, String, String)>)>,
    // global constants, evaluated at load time
    consts: RefCell<HashMap<String, Value>>,
    // pending const expressions to evaluate lazily on first run
    const_exprs: Vec<(String, crate::ast::Expr)>,
    // trait name -> (required method names, default method funcs)
    traits: HashMap<String, (Vec<String>, Vec<crate::ast::Func>)>,
    // --- async scheduler ---
    // ready queue of spawned tasks waiting to run to completion
    ready_queue: RefCell<std::collections::VecDeque<Rc<RefCell<TaskVal>>>>,
    // the body+scope for each spawned task, keyed by task id
    task_bodies: RefCell<HashMap<u64, (Vec<Stmt>, Scope)>>,
    // monotonic id source for tasks
    next_task_id: std::cell::Cell<u64>,
}

impl Interp {
    pub fn new(program: &Program) -> Result<Self, String> {
        let mut funcs = HashMap::new();
        let mut structs = HashMap::new();
        let mut methods = HashMap::new();
        let mut variants = HashMap::new();
        let mut module_aliases = HashMap::new();
        let mut tests = Vec::new();
        let mut machines = HashMap::new();
        let mut const_exprs = Vec::new();
        let mut traits: HashMap<String, (Vec<String>, Vec<crate::ast::Func>)> = HashMap::new();
        // PASS 0: collect trait definitions first, so `impl Trait for Type` can
        // pull in default methods regardless of declaration order.
        for item in &program.items {
            if let Item::Trait(t) = item {
                traits.insert(t.name.clone(), (t.required.clone(), t.defaults.clone()));
            }
        }
        for item in &program.items {
            match item {
                Item::Func(f) => {
                    if funcs.contains_key(&f.name) {
                        return Err(format!("duplicate function: {}", f.name));
                    }
                    funcs.insert(f.name.clone(), f.clone());
                }
                Item::Struct(s) => {
                    if structs.contains_key(&s.name) {
                        return Err(format!("duplicate struct: {}", s.name));
                    }
                    structs.insert(s.name.clone(), s.clone());
                }
                Item::Impl(imp) => {
                    // implemented method names in this block
                    let mut provided: Vec<String> = Vec::new();
                    for m in &imp.methods {
                        methods.insert((imp.type_name.clone(), m.name.clone()), m.clone());
                        provided.push(m.name.clone());
                    }
                    // `impl Trait for Type`: pull in default methods + verify contract
                    if let Some(trait_name) = &imp.trait_name {
                        let (required, defaults) = traits.get(trait_name)
                            .ok_or_else(|| format!("unknown trait: {}", trait_name))?
                            .clone();
                        // add default methods that the impl didn't override
                        for d in &defaults {
                            if !provided.contains(&d.name) {
                                methods.insert((imp.type_name.clone(), d.name.clone()), d.clone());
                                provided.push(d.name.clone());
                            }
                        }
                        // every required method must be provided (directly or by default)
                        for req in &required {
                            if !provided.contains(req) {
                                return Err(format!(
                                    "type `{}` does not implement required method `{}` of trait `{}`",
                                    imp.type_name, req, trait_name
                                ));
                            }
                        }
                    }
                }
                Item::Enum(e) => {
                    for v in &e.variants {
                        if variants.contains_key(&v.name) {
                            return Err(format!("duplicate enum variant: {}", v.name));
                        }
                        variants.insert(v.name.clone(), (e.name.clone(), v.arity));
                    }
                }
                Item::Use(u) => {
                    // stdlib functions are always available as `module.fn` and bare `fn`;
                    // `use` validates the module exists and registers any alias.
                    if !is_known_module(&u.module_root()) {
                        return Err(format!("unknown module: {}", u.module));
                    }
                    if let Some(alias) = &u.alias {
                        module_aliases.insert(alias.clone(), u.module_root());
                    }
                }
                Item::Test(t) => tests.push(t.clone()),
                Item::Machine(m) => {
                    machines.insert(m.name.clone(), (m.initial.clone(), m.transitions.clone()));
                }
                Item::Const { name, value } => {
                    const_exprs.push((name.clone(), value.clone()));
                }
                Item::Trait(_) => { /* collected in PASS 0 */ }
                Item::Macro(_) => { /* expanded at parse time */ }
            }
        }
        Ok(Interp {
            funcs, structs, methods, variants, module_aliases,
            pending_throw: RefCell::new(None), tests, machines,
            consts: RefCell::new(HashMap::new()), const_exprs, traits,
            ready_queue: RefCell::new(std::collections::VecDeque::new()),
            task_bodies: RefCell::new(HashMap::new()),
            next_task_id: std::cell::Cell::new(1),
        })
    }

    // Evaluate all global constants into the consts map (idempotent).
    fn init_consts(&self) -> Result<(), String> {
        if !self.consts.borrow().is_empty() || self.const_exprs.is_empty() { return Ok(()); }
        let empty: Scope = HashMap::new();
        for (name, expr) in &self.const_exprs {
            let v = self.eval(expr, &empty)?;
            self.consts.borrow_mut().insert(name.clone(), v);
        }
        Ok(())
    }

    // Run all `test "..." { ... }` blocks and report pass/fail. Returns the
    // number of failures (0 = all passed). Each block runs in a fresh scope.
    pub fn run_tests(&self) -> i32 {
        let _ = self.init_consts();
        if self.tests.is_empty() {
            println!("no tests found");
            return 0;
        }
        let mut passed = 0;
        let mut failed = 0;
        println!("running {} test(s)\n", self.tests.len());
        for t in &self.tests {
            let mut scope: Scope = HashMap::new();
            match self.exec_block(&t.body, &mut scope) {
                Ok(_) => {
                    println!("  PASS  {}", t.name);
                    passed += 1;
                }
                Err(e) => {
                    let msg = if e == THROW_SENTINEL {
                        self.pending_throw.borrow_mut().take()
                            .map(|v| v.to_string())
                            .unwrap_or_else(|| "assertion failed".to_string())
                    } else {
                        e
                    };
                    println!("  FAIL  {}  ({})", t.name, msg);
                    failed += 1;
                }
            }
        }
        println!("\n{} passed, {} failed", passed, failed);
        failed
    }

    pub fn run(&self) -> Result<Value, String> {
        if !self.funcs.contains_key("main") {
            return Err("no `main` function found".into());
        }
        self.init_consts()?;
        let result = self.call("main", vec![]);
        // Drive any still-queued fire-and-forget tasks to completion.
        self.drain_tasks()?;
        match result {
            Err(e) if e == THROW_SENTINEL => {
                let v = self.pending_throw.borrow_mut().take().unwrap_or(Value::Null);
                Err(format!("uncaught exception: {}", v))
            }
            other => other,
        }
    }

    // Run every task left in the ready queue until it is empty. Used after main
    // so spawned tasks that were never awaited still get to run.
    fn drain_tasks(&self) -> Result<(), String> {
        let mut guard = 0;
        loop {
            let next = self.ready_queue.borrow_mut().pop_front();
            match next {
                Some(task) => {
                    let id = task.borrow().id;
                    self.run_task(id, &task)?;
                }
                None => return Ok(()),
            }
            guard += 1;
            if guard > 1_000_000 {
                return Err("scheduler: too many tasks (possible runaway spawn)".into());
            }
        }
    }

    // Register the items (functions, structs, impls, enums, uses) of a freshly
    // parsed program into this interpreter, mutating its tables. Used by the REPL
    // so definitions persist across input lines.
    pub fn register_items(&mut self, program: &Program) -> Result<(), String> {
        for item in &program.items {
            match item {
                Item::Func(f) => { self.funcs.insert(f.name.clone(), f.clone()); }
                Item::Struct(s) => { self.structs.insert(s.name.clone(), s.clone()); }
                Item::Impl(imp) => {
                    for m in &imp.methods {
                        self.methods.insert((imp.type_name.clone(), m.name.clone()), m.clone());
                    }
                }
                Item::Enum(e) => {
                    for v in &e.variants {
                        self.variants.insert(v.name.clone(), (e.name.clone(), v.arity));
                    }
                }
                Item::Use(u) => {
                    if !is_known_module(&u.module_root()) {
                        return Err(format!("unknown module: {}", u.module));
                    }
                    if let Some(alias) = &u.alias {
                        self.module_aliases.insert(alias.clone(), u.module_root());
                    }
                }
                Item::Test(_) => {} // tests are ignored in REPL mode
                Item::Machine(m) => {
                    self.machines.insert(m.name.clone(), (m.initial.clone(), m.transitions.clone()));
                }
                Item::Const { name, value } => {
                    let empty: Scope = HashMap::new();
                    let v = self.eval(value, &empty)?;
                    self.consts.borrow_mut().insert(name.clone(), v);
                }
                Item::Trait(t) => {
                    self.traits.insert(t.name.clone(), (t.required.clone(), t.defaults.clone()));
                }
                Item::Macro(_) => {}
            }
        }
        Ok(())
    }

    // Execute a single REPL statement/expression list in a persistent scope.
    // Returns the value of the last expression statement, if any, for printing.
    pub fn eval_repl(&self, stmts: &[Stmt], scope: &mut Scope) -> Result<Option<Value>, String> {
        let mut last_value: Option<Value> = None;
        for stmt in stmts {
            // capture the value of a bare expression so the REPL can echo it
            if let Stmt::Expr(e) = stmt {
                let v = self.eval(e, scope)?;
                last_value = Some(v);
                continue;
            }
            match self.exec_stmt(stmt, scope) {
                Ok(Flow::Normal) => { last_value = None; }
                Ok(Flow::Return(v)) => { last_value = Some(v); }
                Ok(Flow::Break(v)) => { last_value = Some(v); }
                Ok(Flow::Continue) => { last_value = None; }
                Ok(Flow::Throw(v)) => return Err(format!("uncaught exception: {}", v)),
                Err(e) if e == THROW_SENTINEL => {
                    let v = self.pending_throw.borrow_mut().take().unwrap_or(Value::Null);
                    return Err(format!("uncaught exception: {}", v));
                }
                Err(e) => return Err(e),
            }
        }
        Ok(last_value)
    }

    fn call(&self, name: &str, args: Vec<Value>) -> Result<Value, String> {
        // built-in functions
        match name {
            "print" => {
                let line = args.iter().map(|v| v.to_string()).collect::<Vec<_>>().join(" ");
                println!("{}", line);
                return Ok(Value::Null);
            }
            "send" => {
                let inst = match args.get(0) {
                    Some(Value::Struct(s)) => s.clone(),
                    _ => return Err("send expects a state machine as first argument".into()),
                };
                let event = match args.get(1) {
                    Some(Value::Str(s)) => s.clone(),
                    _ => return Err("send expects an event string as second argument".into()),
                };
                let type_name = inst.borrow().type_name.clone();
                let (_, transitions) = self.machines.get(&type_name)
                    .ok_or_else(|| format!("{} is not a state machine", type_name))?;
                let current = match inst.borrow().fields.get("state") {
                    Some(Value::Str(s)) => s.clone(),
                    _ => return Err("machine has no state".into()),
                };
                for (from, to, ev) in transitions {
                    if from == &current && ev == &event {
                        inst.borrow_mut().fields.insert("state".to_string(), Value::Str(to.clone()));
                        return Ok(Value::Str(to.clone()));
                    }
                }
                *self.pending_throw.borrow_mut() = Some(Value::Str(
                    format!("invalid transition: {} cannot handle '{}' in state {}", type_name, event, current)
                ));
                return Err(THROW_SENTINEL.to_string());
            }
            "state_of" => {
                let inst = match args.get(0) {
                    Some(Value::Struct(s)) => s.clone(),
                    _ => return Err("state_of expects a state machine".into()),
                };
                let st = inst.borrow().fields.get("state").cloned().unwrap_or(Value::Null);
                return Ok(st);
            }
            "assert" => {
                let cond = args.get(0).ok_or("assert expects a condition")?;
                if !cond.is_truthy() {
                    let msg = args.get(1).map(|v| v.to_string())
                        .unwrap_or_else(|| "assertion failed".to_string());
                    // throw so a test harness (or try/catch) can capture it
                    *self.pending_throw.borrow_mut() = Some(Value::Str(msg));
                    return Err(THROW_SENTINEL.to_string());
                }
                return Ok(Value::Null);
            }
            "assert_eq" => {
                let a = args.get(0).ok_or("assert_eq expects two values")?;
                let b = args.get(1).ok_or("assert_eq expects two values")?;
                if !values_eq(a, b) {
                    let msg = format!("assertion failed: {} != {}", a, b);
                    *self.pending_throw.borrow_mut() = Some(Value::Str(msg));
                    return Err(THROW_SENTINEL.to_string());
                }
                return Ok(Value::Null);
            }
            "len" => {
                let v = args.get(0).ok_or("len expects 1 argument")?;
                return match v {
                    Value::Array(a) => Ok(Value::Int(a.borrow().len() as i64)),
                    Value::Str(s) => Ok(Value::Int(s.chars().count() as i64)),
                    other => Err(format!("len expects array or string, got {}", other.type_name())),
                };
            }
            "push" => {
                let arr = args.get(0).ok_or("push expects (array, value)")?;
                let val = args.get(1).ok_or("push expects (array, value)")?.clone();
                return match arr {
                    Value::Array(a) => { a.borrow_mut().push(val); Ok(Value::Null) }
                    other => Err(format!("push expects array, got {}", other.type_name())),
                };
            }
            "pop" => {
                let arr = args.get(0).ok_or("pop expects (array)")?;
                return match arr {
                    Value::Array(a) => Ok(a.borrow_mut().pop().unwrap_or(Value::Null)),
                    other => Err(format!("pop expects array, got {}", other.type_name())),
                };
            }
            "str" => {
                let v = args.get(0).ok_or("str expects 1 argument")?;
                return Ok(Value::Str(v.to_string()));
            }
            "int" => {
                let v = args.get(0).ok_or("int expects 1 argument")?;
                return match v {
                    Value::Int(n) => Ok(Value::Int(*n)),
                    Value::BigInt(b) => Ok(Value::BigInt(b.clone())),
                    Value::Float(x) => Ok(Value::Int(*x as i64)),
                    Value::Str(s) => s.trim().parse::<i64>().map(Value::Int)
                        .map_err(|_| format!("cannot parse '{}' as int", s)),
                    Value::Bool(b) => Ok(Value::Int(if *b { 1 } else { 0 })),
                    other => Err(format!("cannot convert {} to int", other.type_name())),
                };
            }
            "float" => {
                let v = args.get(0).ok_or("float expects 1 argument")?;
                return match v {
                    Value::Int(n) => Ok(Value::Float(*n as f64)),
                    Value::Float(x) => Ok(Value::Float(*x)),
                    Value::Str(s) => s.trim().parse::<f64>().map(Value::Float)
                        .map_err(|_| format!("cannot parse '{}' as float", s)),
                    other => Err(format!("cannot convert {} to float", other.type_name())),
                };
            }
            "abs" => {
                let v = args.get(0).ok_or("abs expects 1 argument")?;
                return match v {
                    Value::Int(n) => Ok(Value::Int(n.abs())),
                    Value::BigInt(b) => Ok(norm_big(b.abs())),
                    Value::Float(x) => Ok(Value::Float(x.abs())),
                    other => Err(format!("abs expects number, got {}", other.type_name())),
                };
            }
            "sqrt" => {
                let v = args.get(0).ok_or("sqrt expects 1 argument")?;
                let f = match v {
                    Value::Int(n) => *n as f64,
                    Value::Float(x) => *x,
                    other => return Err(format!("sqrt expects number, got {}", other.type_name())),
                };
                return Ok(Value::Float(f.sqrt()));
            }
            "array_fill" => {
                // array_fill(value, count) backs the [v; n] literal
                let fill = args.get(0).cloned().unwrap_or(Value::Null);
                let n = match args.get(1) {
                    Some(Value::Int(n)) if *n >= 0 => *n as usize,
                    _ => return Err("[v; n] expects a non-negative integer count".into()),
                };
                return Ok(Value::Array(Rc::new(RefCell::new(vec![fill; n]))));
            }
            "array" => {
                // array(n, fill) -> new array of n copies, or array() -> empty
                if args.is_empty() {
                    return Ok(Value::Array(Rc::new(RefCell::new(Vec::new()))));
                }
                let n = match args.get(0) {
                    Some(Value::Int(n)) if *n >= 0 => *n as usize,
                    _ => return Err("array(n, fill) expects a non-negative int size".into()),
                };
                let fill = args.get(1).cloned().unwrap_or(Value::Null);
                return Ok(Value::Array(Rc::new(RefCell::new(vec![fill; n]))));
            }
            "map" => {
                let arr = expect_array(args.get(0), "map")?;
                let f = args.get(1).cloned().ok_or("map(array, fn) expects 2 args")?;
                let items: Vec<Value> = arr.borrow().clone();
                let mut out = Vec::with_capacity(items.len());
                for item in items {
                    out.push(self.call_closure(&f, vec![item])?);
                }
                return Ok(Value::Array(Rc::new(RefCell::new(out))));
            }
            "filter" => {
                let arr = expect_array(args.get(0), "filter")?;
                let f = args.get(1).cloned().ok_or("filter(array, fn) expects 2 args")?;
                let items: Vec<Value> = arr.borrow().clone();
                let mut out = Vec::new();
                for item in items {
                    if self.call_closure(&f, vec![item.clone()])?.is_truthy() {
                        out.push(item);
                    }
                }
                return Ok(Value::Array(Rc::new(RefCell::new(out))));
            }
            "reduce" => {
                let arr = expect_array(args.get(0), "reduce")?;
                let f = args.get(1).cloned().ok_or("reduce(array, fn, init) expects 3 args")?;
                let init = args.get(2).cloned().ok_or("reduce(array, fn, init) expects 3 args")?;
                let items: Vec<Value> = arr.borrow().clone();
                let mut acc = init;
                for item in items {
                    acc = self.call_closure(&f, vec![acc, item])?;
                }
                return Ok(acc);
            }
            "range" => {
                // range(n) -> [0, 1, ..., n-1] ; range(a, b) -> [a..b)
                let (start, end) = match (args.get(0), args.get(1)) {
                    (Some(Value::Int(n)), None) => (0, *n),
                    (Some(Value::Int(a)), Some(Value::Int(b))) => (*a, *b),
                    _ => return Err("range(n) or range(a, b) expects integers".into()),
                };
                let mut v = Vec::new();
                let mut i = start;
                while i < end { v.push(Value::Int(i)); i += 1; }
                return Ok(Value::Array(Rc::new(RefCell::new(v))));
            }
            "dict" => {
                // dict() -> new empty key-value map
                if !args.is_empty() {
                    return Err("dict() takes no arguments".into());
                }
                return Ok(Value::Map(Rc::new(RefCell::new(Vec::new()))));
            }
            "chan" => {
                // chan() -> unbounded channel; chan(n) -> capacity hint (advisory)
                let cap = match args.get(0) {
                    Some(Value::Int(n)) if *n >= 0 => *n as usize,
                    None => 0,
                    _ => return Err("chan(cap) expects a non-negative integer".into()),
                };
                let c = ChannelVal { buffer: std::collections::VecDeque::new(), capacity: cap, closed: false };
                return Ok(Value::Channel(Rc::new(RefCell::new(c))));
            }
            "recv" => {
                let ch = args.get(0).ok_or("recv expects a channel")?.clone();
                return self.channel_recv(ch);
            }
            "send_to" => {
                // send_to(ch, v): function form of `ch <- v`
                let ch = args.get(0).ok_or("send_to expects (channel, value)")?.clone();
                let v = args.get(1).ok_or("send_to expects (channel, value)")?.clone();
                return match ch {
                    Value::Channel(c) => {
                        if c.borrow().closed {
                            *self.pending_throw.borrow_mut() =
                                Some(Value::Str("send on closed channel".into()));
                            return Err(THROW_SENTINEL.to_string());
                        }
                        c.borrow_mut().buffer.push_back(v);
                        Ok(Value::Null)
                    }
                    other => Err(format!("send_to expects a channel, got {}", other.type_name())),
                };
            }
            "close" => {
                let ch = args.get(0).ok_or("close expects a channel")?;
                return match ch {
                    Value::Channel(c) => { c.borrow_mut().closed = true; Ok(Value::Null) }
                    other => Err(format!("close expects a channel, got {}", other.type_name())),
                };
            }
            "chan_len" => {
                let ch = args.get(0).ok_or("chan_len expects a channel")?;
                return match ch {
                    Value::Channel(c) => Ok(Value::Int(c.borrow().buffer.len() as i64)),
                    other => Err(format!("chan_len expects a channel, got {}", other.type_name())),
                };
            }
            "await" => {
                // await(x): function form of `x.await`, drives a future/task
                let v = args.get(0).ok_or("await expects 1 argument")?.clone();
                return self.drive_to_value(v);
            }
            "is_pending" => {
                // introspection: true if a future/task hasn't resolved yet
                let v = args.get(0).ok_or("is_pending expects 1 argument")?;
                let pending = match v {
                    Value::Future(f) => matches!(f.borrow().state, FutureState::Pending | FutureState::Running),
                    Value::Task(t) => matches!(t.borrow().state, FutureState::Pending | FutureState::Running),
                    _ => false,
                };
                return Ok(Value::Bool(pending));
            }
            "map_set" => {
                let m = expect_map(args.get(0), "map_set")?;
                let key = args.get(1).cloned().ok_or("map_set(m, key, value) expects 3 args")?;
                let val = args.get(2).cloned().ok_or("map_set(m, key, value) expects 3 args")?;
                let mut entries = m.borrow_mut();
                if let Some(slot) = entries.iter_mut().find(|(k, _)| values_eq(k, &key)) {
                    slot.1 = val;
                } else {
                    entries.push((key, val));
                }
                return Ok(Value::Null);
            }
            "map_get" => {
                let m = expect_map(args.get(0), "map_get")?;
                let key = args.get(1).ok_or("map_get(m, key) expects 2 args")?;
                let entries = m.borrow();
                for (k, v) in entries.iter() {
                    if values_eq(k, key) { return Ok(v.clone()); }
                }
                // optional 3rd arg is a default
                return Ok(args.get(2).cloned().unwrap_or(Value::Null));
            }
            "map_has" => {
                let m = expect_map(args.get(0), "map_has")?;
                let key = args.get(1).ok_or("map_has(m, key) expects 2 args")?;
                let found = m.borrow().iter().any(|(k, _)| values_eq(k, key));
                return Ok(Value::Bool(found));
            }
            "map_del" => {
                let m = expect_map(args.get(0), "map_del")?;
                let key = args.get(1).ok_or("map_del(m, key) expects 2 args")?;
                let mut entries = m.borrow_mut();
                let before = entries.len();
                entries.retain(|(k, _)| !values_eq(k, key));
                return Ok(Value::Bool(entries.len() != before));
            }
            "map_keys" => {
                let m = expect_map(args.get(0), "map_keys")?;
                let keys: Vec<Value> = m.borrow().iter().map(|(k, _)| k.clone()).collect();
                return Ok(Value::Array(Rc::new(RefCell::new(keys))));
            }
            "map_values" => {
                let m = expect_map(args.get(0), "map_values")?;
                let vals: Vec<Value> = m.borrow().iter().map(|(_, v)| v.clone()).collect();
                return Ok(Value::Array(Rc::new(RefCell::new(vals))));
            }
            "map_len" => {
                let m = expect_map(args.get(0), "map_len")?;
                let n = m.borrow().len() as i64;
                return Ok(Value::Int(n));
            }
            _ => {}
        }

        // standard library functions (math.*, strings.*, arrays.*, or bare after `use`)
        if let Some(v) = call_stdlib(name, &args)? {
            return Ok(v);
        }

        let func = self.funcs.get(name)
            .ok_or_else(|| format!("call to undefined function: {}", name))?;
        if args.len() != func.params.len() {
            return Err(format!(
                "function `{}` expects {} args, got {}",
                name, func.params.len(), args.len()
            ));
        }
        let mut scope: Scope = HashMap::new();
        for (p, v) in func.params.iter().zip(args.into_iter()) {
            scope.insert(p.clone(), v);
        }
        // An `async fn` does not run now: it captures its body + bound scope into
        // a pending Future. The caller drives it with `.await`.
        if func.is_async {
            let fut = FutureVal {
                body: func.body.clone(),
                scope,
                state: FutureState::Pending,
            };
            return Ok(Value::Future(Rc::new(RefCell::new(fut))));
        }
        match self.exec_block(&func.body, &mut scope)? {
            Flow::Return(v) => Ok(v),
            Flow::Break(v) => Ok(v),
            Flow::Continue => Ok(Value::Null),
            Flow::Throw(e) => {
                *self.pending_throw.borrow_mut() = Some(e);
                Err(THROW_SENTINEL.to_string())
            }
            Flow::Normal => Ok(Value::Null),
        }
    }

    fn match_pattern(&self, pat: &Pattern, val: &Value, bindings: &mut Scope)
        -> Result<bool, String>
    {
        match pat {
            Pattern::Wildcard => Ok(true),
            Pattern::Binding(name) => {
                bindings.insert(name.clone(), val.clone());
                Ok(true)
            }
            Pattern::Int(n) => Ok(matches!(val, Value::Int(m) if m == n)),
            Pattern::Float(x) => Ok(matches!(val, Value::Float(y) if y == x)),
            Pattern::Str(s) => Ok(matches!(val, Value::Str(t) if t == s)),
            Pattern::Bool(b) => Ok(matches!(val, Value::Bool(c) if c == b)),
            Pattern::Null => Ok(matches!(val, Value::Null)),
            Pattern::Range { lo, hi, inclusive } => {
                match val {
                    Value::Int(n) => {
                        let ok = if *inclusive { *n >= *lo && *n <= *hi }
                                 else { *n >= *lo && *n < *hi };
                        Ok(ok)
                    }
                    _ => Ok(false),
                }
            }
            Pattern::Or(alts) => {
                for alt in alts {
                    let mut sub = bindings.clone();
                    if self.match_pattern(alt, val, &mut sub)? {
                        *bindings = sub;
                        return Ok(true);
                    }
                }
                Ok(false)
            }
            Pattern::Tuple(subs) => {
                match val {
                    Value::Array(a) => {
                        let arr = a.borrow();
                        if arr.len() != subs.len() { return Ok(false); }
                        for (p, v) in subs.iter().zip(arr.iter()) {
                            if !self.match_pattern(p, v, bindings)? { return Ok(false); }
                        }
                        Ok(true)
                    }
                    _ => Ok(false),
                }
            }
            Pattern::Struct { name, fields } => {
                match val {
                    Value::Struct(s) => {
                        let inst = s.borrow();
                        if !name.is_empty() && &inst.type_name != name { return Ok(false); }
                        for (fname, fpat) in fields {
                            match inst.fields.get(fname) {
                                Some(fv) => {
                                    if !self.match_pattern(fpat, fv, bindings)? { return Ok(false); }
                                }
                                None => return Ok(false),
                            }
                        }
                        Ok(true)
                    }
                    _ => Ok(false),
                }
            }
            Pattern::EnumVariant { name, sub } => {
                match val {
                    Value::Enum(e) => {
                        if &e.variant != name {
                            return Ok(false);
                        }
                        if sub.len() != e.data.len() {
                            return Ok(false);
                        }
                        for (p, v) in sub.iter().zip(e.data.iter()) {
                            if !self.match_pattern(p, v, bindings)? {
                                return Ok(false);
                            }
                        }
                        Ok(true)
                    }
                    _ => Ok(false),
                }
            }
        }
    }

    fn call_closure(&self, f: &Value, args: Vec<Value>) -> Result<Value, String> {
        let c = match f {
            Value::Closure(c) => c.clone(),
            other => return Err(format!("cannot call {} as a function", other.type_name())),
        };
        if args.len() != c.params.len() {
            return Err(format!(
                "closure expects {} args, got {}",
                c.params.len(), args.len()
            ));
        }
        // start from captured environment, then bind parameters
        let mut scope: Scope = c.captured.clone();
        for (p, v) in c.params.iter().zip(args.into_iter()) {
            scope.insert(p.clone(), v);
        }
        match &c.body {
            LambdaBody::Expr(e) => self.eval(e, &scope),
            LambdaBody::Block(stmts) => {
                match self.exec_block(stmts, &mut scope)? {
                    Flow::Return(v) => Ok(v),
                    Flow::Break(v) => Ok(v),
                    Flow::Continue => Ok(Value::Null),
                    Flow::Throw(e) => {
                *self.pending_throw.borrow_mut() = Some(e);
                Err(THROW_SENTINEL.to_string())
            }
                    Flow::Normal => Ok(Value::Null),
                }
            }
        }
    }

    fn call_method(&self, receiver: Value, method: &str, args: &[Expr], scope: &Scope)
        -> Result<Value, String>
    {
        // evaluate args first
        let mut argvals = Vec::with_capacity(args.len());
        for a in args { argvals.push(self.eval(a, scope)?); }

        // built-in array methods
        if let Value::Array(ref a) = receiver {
            match method {
                "len" => return Ok(Value::Int(a.borrow().len() as i64)),
                "push" => {
                    let v = argvals.get(0).cloned().ok_or("push expects 1 argument")?;
                    a.borrow_mut().push(v);
                    return Ok(Value::Null);
                }
                "pop" => return Ok(a.borrow_mut().pop().unwrap_or(Value::Null)),
                "get" => {
                    let idx = as_int(argvals.get(0))?;
                    let arr = a.borrow();
                    if idx < 0 || idx as usize >= arr.len() {
                        return Ok(Value::Null);
                    }
                    return Ok(arr[idx as usize].clone());
                }
                _ => {}
            }
        }
        // built-in string methods
        if let Value::Str(ref s) = receiver {
            match method {
                "len" => return Ok(Value::Int(s.chars().count() as i64)),
                "upper" => return Ok(Value::Str(s.to_uppercase())),
                "lower" => return Ok(Value::Str(s.to_lowercase())),
                _ => {}
            }
        }

        // user-defined struct methods
        if let Value::Struct(ref inst) = receiver {
            let type_name = inst.borrow().type_name.clone();
            let key = (type_name.clone(), method.to_string());
            let func = self.methods.get(&key)
                .ok_or_else(|| format!("type {} has no method: {}", type_name, method))?
                .clone();
            // bind self + params
            let mut mscope: Scope = HashMap::new();
            let mut pi = 0;
            // first param is `self` by convention if present
            if func.params.get(0).map(|p| p == "self").unwrap_or(false) {
                mscope.insert("self".to_string(), receiver.clone());
                pi = 1;
            }
            let expected = func.params.len() - pi;
            if argvals.len() != expected {
                return Err(format!(
                    "method {}.{} expects {} args, got {}",
                    type_name, method, expected, argvals.len()
                ));
            }
            for (p, v) in func.params[pi..].iter().zip(argvals.into_iter()) {
                mscope.insert(p.clone(), v);
            }
            return match self.exec_block(&func.body, &mut mscope)? {
                Flow::Return(v) => Ok(v),
                Flow::Break(v) => Ok(v),
                Flow::Continue => Ok(Value::Null),
                Flow::Throw(e) => {
                *self.pending_throw.borrow_mut() = Some(e);
                Err(THROW_SENTINEL.to_string())
            }
                Flow::Normal => Ok(Value::Null),
            };
        }

        Err(format!("cannot call method '{}' on {}", method, receiver.type_name()))
    }

    fn exec_block(&self, stmts: &[Stmt], scope: &mut Scope) -> Result<Flow, String> {
        // Collect deferred blocks and run them in reverse order on the way out,
        // regardless of how the block exits (normal, return, throw, or error).
        let mut deferred: Vec<&[Stmt]> = Vec::new();
        let outcome = self.exec_block_inner(stmts, scope, &mut deferred);
        // run defers LIFO; their own flow/errors are best-effort and don't mask the outcome
        for d in deferred.iter().rev() {
            let mut tmp: Vec<&[Stmt]> = Vec::new();
            let _ = self.exec_block_inner(d, scope, &mut tmp);
        }
        outcome
    }

    fn exec_block_inner<'a>(&self, stmts: &'a [Stmt], scope: &mut Scope, deferred: &mut Vec<&'a [Stmt]>)
        -> Result<Flow, String>
    {
        for stmt in stmts {
            if let Stmt::Defer(body) = stmt {
                deferred.push(body);
                continue;
            }
            match self.exec_stmt(stmt, scope)? {
                Flow::Return(v) => return Ok(Flow::Return(v)),
                Flow::Throw(v) => return Ok(Flow::Throw(v)),
                Flow::Break(v) => return Ok(Flow::Break(v)),
                Flow::Continue => return Ok(Flow::Continue),
                Flow::Normal => {}
            }
        }
        Ok(Flow::Normal)
    }

    fn exec_stmt(&self, stmt: &Stmt, scope: &mut Scope) -> Result<Flow, String> {
        match stmt {
            Stmt::Let { name, value } => {
                let v = self.eval(value, scope)?;
                scope.insert(name.clone(), v);
                Ok(Flow::Normal)
            }
            Stmt::Assign { name, value } => {
                // `let` is optional: assigning to an unknown name defines it.
                let v = self.eval(value, scope)?;
                scope.insert(name.clone(), v);
                Ok(Flow::Normal)
            }
            Stmt::IndexAssign { base, index, value } => {
                let target = self.eval(base, scope)?;
                if let Value::Map(m) = &target {
                    let key = self.eval(index, scope)?;
                    let v = self.eval(value, scope)?;
                    let mut entries = m.borrow_mut();
                    if let Some(slot) = entries.iter_mut().find(|(k, _)| values_eq(k, &key)) {
                        slot.1 = v;
                    } else {
                        entries.push((key, v));
                    }
                    return Ok(Flow::Normal);
                }
                let idx = self.eval_int(index, scope)?;
                let v = self.eval(value, scope)?;
                match target {
                    Value::Array(a) => {
                        let mut arr = a.borrow_mut();
                        if idx < 0 || idx as usize >= arr.len() {
                            return Err(format!("index {} out of bounds (len {})", idx, arr.len()));
                        }
                        arr[idx as usize] = v;
                        Ok(Flow::Normal)
                    }
                    other => Err(format!("cannot index-assign into {}", other.type_name())),
                }
            }
            Stmt::FieldAssign { base, field, value } => {
                let target = self.eval(base, scope)?;
                let v = self.eval(value, scope)?;
                match target {
                    Value::Struct(inst) => {
                        let mut inst = inst.borrow_mut();
                        if !inst.fields.contains_key(field) {
                            return Err(format!("struct {} has no field: {}", inst.type_name, field));
                        }
                        inst.fields.insert(field.clone(), v);
                        Ok(Flow::Normal)
                    }
                    other => Err(format!("cannot assign field '{}' on {}", field, other.type_name())),
                }
            }
            Stmt::Expr(e) => {
                self.eval(e, scope)?;
                Ok(Flow::Normal)
            }
            Stmt::Return(e) => {
                let v = match e {
                    Some(e) => self.eval(e, scope)?,
                    None => Value::Null,
                };
                Ok(Flow::Return(v))
            }
            Stmt::If { cond, then, els } => {
                if self.eval(cond, scope)?.is_truthy() {
                    self.exec_block(then, scope)
                } else if let Some(els) = els {
                    self.exec_block(els, scope)
                } else {
                    Ok(Flow::Normal)
                }
            }
            Stmt::While { cond, body } => {
                let mut guard = 0u64;
                while self.eval(cond, scope)?.is_truthy() {
                    match self.exec_block(body, scope)? {
                        Flow::Return(v) => return Ok(Flow::Return(v)),
                        Flow::Throw(v) => return Ok(Flow::Throw(v)),
                        Flow::Break(_) => return Ok(Flow::Normal),
                        Flow::Continue | Flow::Normal => {}
                    }
                    guard += 1;
                    if guard > 100_000_000 {
                        return Err("while loop exceeded 100M iterations (likely infinite)".into());
                    }
                }
                Ok(Flow::Normal)
            }
            Stmt::ForRange { var, start, end, inclusive, body } => {
                let s = self.eval_int(start, scope)?;
                let e = self.eval_int(end, scope)?;
                let last = if *inclusive { e } else { e - 1 };
                let mut i = s;
                while i <= last {
                    scope.insert(var.clone(), Value::Int(i));
                    match self.exec_block(body, scope)? {
                        Flow::Return(v) => return Ok(Flow::Return(v)),
                        Flow::Throw(v) => return Ok(Flow::Throw(v)),
                        Flow::Break(_) => return Ok(Flow::Normal),
                        Flow::Continue | Flow::Normal => {}
                    }
                    i += 1;
                }
                Ok(Flow::Normal)
            }
            Stmt::ForEach { var, iter, body } => {
                let collection = self.eval(iter, scope)?;
                match collection {
                    Value::Array(a) => {
                        // snapshot to a Vec so mutation during iteration is well-defined
                        let items: Vec<Value> = a.borrow().clone();
                        for item in items {
                            scope.insert(var.clone(), item);
                            match self.exec_block(body, scope)? {
                                Flow::Return(v) => return Ok(Flow::Return(v)),
                                Flow::Throw(v) => return Ok(Flow::Throw(v)),
                                Flow::Break(_) => return Ok(Flow::Normal),
                                Flow::Continue | Flow::Normal => {}
                            }
                        }
                        Ok(Flow::Normal)
                    }
                    Value::Str(s) => {
                        for ch in s.chars() {
                            scope.insert(var.clone(), Value::Str(ch.to_string()));
                            match self.exec_block(body, scope)? {
                                Flow::Return(v) => return Ok(Flow::Return(v)),
                                Flow::Throw(v) => return Ok(Flow::Throw(v)),
                                Flow::Break(_) => return Ok(Flow::Normal),
                                Flow::Continue | Flow::Normal => {}
                            }
                        }
                        Ok(Flow::Normal)
                    }
                    other => Err(format!("cannot iterate over {}", other.type_name())),
                }
            }
            Stmt::Throw(e) => {
                let v = self.eval(e, scope)?;
                Ok(Flow::Throw(v))
            }
            Stmt::Break(e) => {
                let v = match e { Some(ex) => self.eval(ex, scope)?, None => Value::Null };
                Ok(Flow::Break(v))
            }
            Stmt::Continue => Ok(Flow::Continue),
            Stmt::Defer(body) => {
                // fallback: if a defer reaches exec_stmt directly, run it immediately
                self.exec_block(body, scope)
            }
            Stmt::TryCatch { body, catch_var, catch_body, finally_body } => {
                // Run the body. A throw can surface two ways:
                //  - Flow::Throw  (threw directly in this block)
                //  - Err(SENTINEL) with the value parked in pending_throw
                //    (threw deeper inside a called function)
                let body_result = self.exec_block(body, scope);
                let outcome = match body_result {
                    Ok(flow) => flow,
                    Err(e) => {
                        if e == THROW_SENTINEL {
                            let v = self.pending_throw.borrow_mut().take().unwrap_or(Value::Null);
                            Flow::Throw(v)
                        } else {
                            // genuine runtime error: run finally, then propagate
                            if let Some(fin) = finally_body {
                                self.exec_block(fin, scope)?;
                            }
                            return Err(e);
                        }
                    }
                };

                let result = match outcome {
                    Flow::Throw(err) => {
                        if let Some(catch) = catch_body {
                            if let Some(var) = catch_var {
                                scope.insert(var.clone(), err);
                            }
                            // catch body itself may throw/return
                            match self.exec_block(catch, scope) {
                                Ok(flow) => flow,
                                Err(e) => {
                                    if let Some(fin) = finally_body {
                                        self.exec_block(fin, scope)?;
                                    }
                                    return Err(e);
                                }
                            }
                        } else {
                            Flow::Normal // no handler — swallow; finally still runs
                        }
                    }
                    other => other, // Normal / Return propagate after finally
                };

                if let Some(fin) = finally_body {
                    match self.exec_block(fin, scope)? {
                        Flow::Normal => {}
                        other => return Ok(other), // return/throw in finally wins
                    }
                }
                Ok(result)
            }
        }
    }

    // Slice an array or string by a (possibly open, possibly inclusive) range.
    // Negative bounds count from the end: a[-2..] is the last two elements.
    fn eval_slice(&self, base: &Expr, lo: &Option<Box<Expr>>, hi: &Option<Box<Expr>>,
                  inclusive: bool, scope: &Scope) -> Result<Value, String> {
        let target = self.eval(base, scope)?;
        let len = match &target {
            Value::Array(a) => a.borrow().len(),
            Value::Str(s) => s.chars().count(),
            other => return Err(format!("cannot slice {}", other.type_name())),
        } as i64;
        let start = match lo {
            Some(e) => { let v = self.eval_int(e, scope)?; if v < 0 { (len + v).max(0) } else { v.min(len) } }
            None => 0,
        };
        let mut end = match hi {
            Some(e) => {
                let raw = self.eval_int(e, scope)?;
                let mut x = if raw < 0 { len + raw } else { raw };
                if inclusive { x += 1; }
                x.clamp(0, len)
            }
            None => len,
        };
        if end < start { end = start; }
        let (s, e) = (start as usize, end as usize);
        match target {
            Value::Array(a) => Ok(Value::Array(Rc::new(RefCell::new(a.borrow()[s..e].to_vec())))),
            Value::Str(string) => {
                let chars: Vec<char> = string.chars().collect();
                Ok(Value::Str(chars[s..e].iter().collect()))
            }
            _ => unreachable!(),
        }
    }

    fn eval_int(&self, e: &Expr, scope: &Scope) -> Result<i64, String> {
        match self.eval(e, scope)? {
            Value::Int(n) => Ok(n),
            other => Err(format!("expected integer, got {}", other.type_name())),
        }
    }

    fn eval(&self, e: &Expr, scope: &Scope) -> Result<Value, String> {
        match e {
            Expr::Int(n) => Ok(Value::Int(*n)),
            Expr::BigIntLit(s) => {
                use std::str::FromStr;
                BigInt::from_str(s).map(norm_big)
                    .map_err(|_| format!("bad big integer literal: {}", s))
            }
            Expr::Float(x) => Ok(Value::Float(*x)),
            Expr::Str(s) => Ok(Value::Str(s.clone())),
            Expr::Bool(b) => Ok(Value::Bool(*b)),
            Expr::Null => Ok(Value::Null),
            Expr::Array(elems) => {
                let mut vals = Vec::with_capacity(elems.len());
                for e in elems {
                    vals.push(self.eval(e, scope)?);
                }
                Ok(Value::Array(Rc::new(RefCell::new(vals))))
            }
            Expr::MapLit(entries) => {
                let mut pairs = Vec::with_capacity(entries.len());
                for (k, v) in entries {
                    let kv = self.eval(k, scope)?;
                    let vv = self.eval(v, scope)?;
                    // last-write-wins on duplicate keys
                    if let Some(slot) = pairs.iter_mut().find(|(ek, _): &&mut (Value, Value)| values_eq(ek, &kv)) {
                        slot.1 = vv;
                    } else {
                        pairs.push((kv, vv));
                    }
                }
                Ok(Value::Map(Rc::new(RefCell::new(pairs))))
            }
            Expr::SetLit(elems) => {
                // a set is a map from element -> null, preserving uniqueness
                let mut pairs: Vec<(Value, Value)> = Vec::with_capacity(elems.len());
                for e in elems {
                    let ev = self.eval(e, scope)?;
                    if !pairs.iter().any(|(k, _)| values_eq(k, &ev)) {
                        pairs.push((ev, Value::Null));
                    }
                }
                Ok(Value::Map(Rc::new(RefCell::new(pairs))))
            }
            Expr::Comprehension { body, var, iter, cond } => {
                let src = self.eval(iter, scope)?;
                let items: Vec<Value> = match src {
                    Value::Array(a) => a.borrow().clone(),
                    Value::Map(m) => m.borrow().iter().map(|(k, _)| k.clone()).collect(),
                    other => return Err(format!("cannot iterate over {} in comprehension", other.type_name())),
                };
                let mut out = Vec::new();
                let mut local = scope.clone();
                for item in items {
                    local.insert(var.clone(), item);
                    let keep = match cond {
                        Some(c) => self.eval(c, &local)?.is_truthy(),
                        None => true,
                    };
                    if keep {
                        out.push(self.eval(body, &local)?);
                    }
                }
                Ok(Value::Array(Rc::new(RefCell::new(out))))
            }
            Expr::FmtStr(parts) => {
                let mut s = String::new();
                for part in parts {
                    match part {
                        FmtPart::Lit(t) => s.push_str(t),
                        FmtPart::Expr(e) => s.push_str(&self.eval(e, scope)?.to_string()),
                    }
                }
                Ok(Value::Str(s))
            }
            Expr::Index { base, index } => {
                // a[lo..hi] — indexing with a range produces a slice
                if let Expr::RangeLit { lo, hi, inclusive } = &**index {
                    return self.eval_slice(base, lo, hi, *inclusive, scope);
                }
                let target = self.eval(base, scope)?;
                match target {
                    Value::Map(m) => {
                        let key = self.eval(index, scope)?;
                        let entries = m.borrow();
                        for (k, v) in entries.iter() {
                            if values_eq(k, &key) { return Ok(v.clone()); }
                        }
                        return Ok(Value::Null);
                    }
                    _ => {}
                }
                let idx = self.eval_int(index, scope)?;
                match target {
                    Value::Array(a) => {
                        let arr = a.borrow();
                        if idx < 0 || idx as usize >= arr.len() {
                            return Err(format!("index {} out of bounds (len {})", idx, arr.len()));
                        }
                        Ok(arr[idx as usize].clone())
                    }
                    Value::Str(s) => {
                        let chars: Vec<char> = s.chars().collect();
                        if idx < 0 || idx as usize >= chars.len() {
                            return Err(format!("string index {} out of bounds (len {})", idx, chars.len()));
                        }
                        Ok(Value::Str(chars[idx as usize].to_string()))
                    }
                    other => Err(format!("cannot index into {}", other.type_name())),
                }
            }
            Expr::RangeLit { lo, hi, inclusive } => {
                // a standalone range materializes into an array of integers,
                // e.g. 1..4 -> [1, 2, 3], 1..=4 -> [1, 2, 3, 4]
                let start = match lo { Some(e) => self.eval_int(e, scope)?, None => 0 };
                let end = match hi {
                    Some(e) => self.eval_int(e, scope)?,
                    None => return Err("open-ended range has no concrete length".into()),
                };
                let last = if *inclusive { end } else { end - 1 };
                let mut out = Vec::new();
                let mut i = start;
                while i <= last { out.push(Value::Int(i)); i += 1; }
                Ok(Value::Array(Rc::new(RefCell::new(out))))
            }
            Expr::StructLit { name, fields } => {
                let def = self.structs.get(name)
                    .ok_or_else(|| format!("unknown struct type: {}", name))?
                    .clone();
                let mut field_map = HashMap::new();
                for (fname, fexpr) in fields {
                    let v = self.eval(fexpr, scope)?;
                    field_map.insert(fname.clone(), v);
                }
                // verify all declared fields are present
                for declared in &def.fields {
                    if !field_map.contains_key(declared) {
                        return Err(format!("struct {} missing field: {}", name, declared));
                    }
                }
                // verify no unknown fields
                for given in field_map.keys() {
                    if !def.fields.contains(given) {
                        return Err(format!("struct {} has no field: {}", name, given));
                    }
                }
                Ok(Value::Struct(Rc::new(RefCell::new(StructInstance {
                    type_name: name.clone(),
                    fields: field_map,
                }))))
            }
            Expr::Field { base, field } => {
                let target = self.eval(base, scope)?;
                match target {
                    Value::Struct(inst) => {
                        let inst = inst.borrow();
                        inst.fields.get(field).cloned()
                            .ok_or_else(|| format!("struct {} has no field: {}", inst.type_name, field))
                    }
                    other => Err(format!("cannot access field '{}' on {}", field, other.type_name())),
                }
            }
            Expr::SafeField { base, field } => {
                // a?.b short-circuits to Null when a is Null
                let target = self.eval(base, scope)?;
                match target {
                    Value::Null => Ok(Value::Null),
                    Value::Struct(inst) => {
                        let inst = inst.borrow();
                        Ok(inst.fields.get(field).cloned().unwrap_or(Value::Null))
                    }
                    other => Err(format!("cannot access field '{}' on {}", field, other.type_name())),
                }
            }
            Expr::MethodCall { base, method, args } => {
                // module-alias call: `m.sqrt(...)` where m is an alias for a stdlib module
                if let Expr::Ident(name) = &**base {
                    if !scope.contains_key(name) {
                        if let Some(root) = self.module_aliases.get(name) {
                            let mut argvals = Vec::with_capacity(args.len());
                            for a in args { argvals.push(self.eval(a, scope)?); }
                            let qualified = format!("{}.{}", root, method);
                            if let Some(v) = call_stdlib(&qualified, &argvals)? {
                                return Ok(v);
                            }
                            return Err(format!("module {} has no function {}", root, method));
                        }
                    }
                }
                let receiver = self.eval(base, scope)?;
                self.call_method(receiver, method, args, scope)
            }
            Expr::Lambda { params, body } => {
                // capture the current scope by snapshot (closures see values at creation time;
                // shared mutable state still works because arrays/structs are Rc-backed)
                Ok(Value::Closure(Rc::new(ClosureVal {
                    params: params.clone(),
                    body: (**body).clone(),
                    captured: scope.clone(),
                })))
            }
            Expr::CallValue { callee, args } => {
                let f = self.eval(callee, scope)?;
                let mut argvals = Vec::with_capacity(args.len());
                for a in args { argvals.push(self.eval(a, scope)?); }
                self.call_closure(&f, argvals)
            }
            Expr::Ident(name) => {
                // a bare unit enum variant like `None` / `Nil`
                if let Some((enum_name, arity)) = self.variants.get(name) {
                    if *arity == 0 {
                        return Ok(Value::Enum(Rc::new(EnumVal {
                            enum_name: enum_name.clone(),
                            variant: name.clone(),
                            data: vec![],
                        })));
                    }
                }
                scope.get(name).cloned()
                    .or_else(|| self.consts.borrow().get(name).cloned())
                    .ok_or_else(|| format!("undefined variable: {}", name))
            }
            Expr::Unary { op, expr } => {
                let v = self.eval(expr, scope)?;
                match (op, v) {
                    (UnOp::Neg, Value::Int(n)) => Ok(Value::Int(-n)),
                    (UnOp::Neg, Value::Float(x)) => Ok(Value::Float(-x)),
                    (UnOp::Neg, Value::BigInt(b)) => Ok(norm_big(-b.clone())),
                    (UnOp::Not, Value::Bool(b)) => Ok(Value::Bool(!b)),
                    (UnOp::Not, v) => Ok(Value::Bool(!v.is_truthy())),
                    (UnOp::BitNot, Value::Int(n)) => Ok(Value::Int(!n)),
                    (op, v) => Err(format!("cannot apply {:?} to {}", op, v.type_name())),
                }
            }
            Expr::Binary { op, lhs, rhs } => {
                // short-circuit for && and ||
                match op {
                    BinOp::And => {
                        let l = self.eval(lhs, scope)?;
                        if !l.is_truthy() { return Ok(Value::Bool(false)); }
                        return Ok(Value::Bool(self.eval(rhs, scope)?.is_truthy()));
                    }
                    BinOp::Or => {
                        let l = self.eval(lhs, scope)?;
                        if l.is_truthy() { return Ok(Value::Bool(true)); }
                        return Ok(Value::Bool(self.eval(rhs, scope)?.is_truthy()));
                    }
                    _ => {}
                }
                let l = self.eval(lhs, scope)?;
                let r = self.eval(rhs, scope)?;
                eval_binop(*op, l, r)
            }
            Expr::Call { callee, args } => {
                let mut vals = Vec::with_capacity(args.len());
                for a in args {
                    vals.push(self.eval(a, scope)?);
                }
                // state-machine constructor: TrafficLight() -> struct with `state` field
                if let Some((initial, _)) = self.machines.get(callee) {
                    if !vals.is_empty() {
                        return Err(format!("machine {} takes no constructor args", callee));
                    }
                    let mut fields = HashMap::new();
                    fields.insert("state".to_string(), Value::Str(initial.clone()));
                    return Ok(Value::Struct(Rc::new(RefCell::new(StructInstance {
                        type_name: callee.clone(),
                        fields,
                    }))));
                }
                // enum variant constructor: Some(x), Cons(h, t), ...
                if let Some((enum_name, arity)) = self.variants.get(callee) {
                    if vals.len() != *arity {
                        return Err(format!(
                            "enum variant {} expects {} args, got {}",
                            callee, arity, vals.len()
                        ));
                    }
                    return Ok(Value::Enum(Rc::new(EnumVal {
                        enum_name: enum_name.clone(),
                        variant: callee.clone(),
                        data: vals,
                    })));
                }
                // a local variable bound to a closure shadows a top-level function
                if let Some(v) = scope.get(callee) {
                    if matches!(v, Value::Closure(_)) {
                        let f = v.clone();
                        return self.call_closure(&f, vals);
                    }
                }
                self.call(callee, vals)
            }
            Expr::If { cond, then, els } => {
                if self.eval(cond, scope)?.is_truthy() {
                    self.eval(then, scope)
                } else {
                    self.eval(els, scope)
                }
            }
            Expr::Match { scrutinee, arms } => {
                let val = self.eval(scrutinee, scope)?;
                for arm in arms {
                    let mut bindings: Scope = HashMap::new();
                    if self.match_pattern(&arm.pattern, &val, &mut bindings)? {
                        // evaluate in a scope extended with the pattern bindings
                        let mut arm_scope = scope.clone();
                        for (k, v) in bindings.iter() {
                            arm_scope.insert(k.clone(), v.clone());
                        }
                        // check guard
                        if let Some(guard) = &arm.guard {
                            if !self.eval(guard, &arm_scope)?.is_truthy() {
                                continue;
                            }
                        }
                        return self.eval(&arm.body, &arm_scope);
                    }
                }
                Err("no match arm matched (non-exhaustive match)".into())
            }
            Expr::Block { stmts, tail } => {
                let mut local = scope.clone();
                if let Flow::Return(v) = self.exec_block(stmts, &mut local)? {
                    return Ok(v);
                }
                match tail {
                    Some(t) => self.eval(t, &local),
                    None => Ok(Value::Null),
                }
            }
            Expr::Await(inner) => {
                let v = self.eval(inner, scope)?;
                self.drive_to_value(v)
            }
            Expr::Spawn(body) => {
                // Queue the body as a task; hand back a JoinHandle (Value::Task).
                let id = self.next_task_id.get();
                self.next_task_id.set(id + 1);
                let task = Rc::new(RefCell::new(TaskVal { id, state: FutureState::Pending }));
                self.task_bodies.borrow_mut().insert(id, (body.clone(), scope.clone()));
                self.ready_queue.borrow_mut().push_back(task.clone());
                Ok(Value::Task(task))
            }
            Expr::Send { chan, value } => {
                let ch = self.eval(chan, scope)?;
                let v = self.eval(value, scope)?;
                match ch {
                    Value::Channel(c) => {
                        {
                            let b = c.borrow();
                            if b.closed {
                                *self.pending_throw.borrow_mut() =
                                    Some(Value::Str("send on closed channel".into()));
                                return Err(THROW_SENTINEL.to_string());
                            }
                        }
                        c.borrow_mut().buffer.push_back(v);
                        Ok(Value::Null)
                    }
                    other => Err(format!("`<-` send expects a channel, got {}", other.type_name())),
                }
            }
            Expr::Recv(chan) => {
                let ch = self.eval(chan, scope)?;
                self.channel_recv(ch)
            }
            Expr::Select(arms) => self.eval_select(arms, scope),
        }
    }

    // Drive a Future or Task to a concrete value, running the scheduler as needed.
    fn drive_to_value(&self, v: Value) -> Result<Value, String> {
        match v {
            Value::Future(fut) => {
                // Inspect current state.
                let state = std::mem::replace(&mut fut.borrow_mut().state, FutureState::Running);
                match state {
                    FutureState::Done(val) => {
                        fut.borrow_mut().state = FutureState::Done(val.clone());
                        Ok(val)
                    }
                    FutureState::Failed(e) => {
                        *self.pending_throw.borrow_mut() = Some(e);
                        Err(THROW_SENTINEL.to_string())
                    }
                    FutureState::Running => {
                        Err("await on a future that is already running (cyclic await)".into())
                    }
                    FutureState::Pending => {
                        // Run the body now, in its captured scope.
                        let (body, mut sc) = {
                            let b = fut.borrow();
                            (b.body.clone(), b.scope.clone())
                        };
                        let result = self.run_async_body(&body, &mut sc);
                        match result {
                            Ok(val) => {
                                fut.borrow_mut().state = FutureState::Done(val.clone());
                                Ok(val)
                            }
                            Err(e) => {
                                if e == THROW_SENTINEL {
                                    let tv = self.pending_throw.borrow().clone().unwrap_or(Value::Null);
                                    fut.borrow_mut().state = FutureState::Failed(tv);
                                }
                                Err(e)
                            }
                        }
                    }
                }
            }
            Value::Task(task) => {
                let id = task.borrow().id;
                // If already done, return cached value.
                {
                    let st = &task.borrow().state;
                    if let FutureState::Done(val) = st { return Ok(val.clone()); }
                    if let FutureState::Failed(e) = st {
                        *self.pending_throw.borrow_mut() = Some(e.clone());
                        return Err(THROW_SENTINEL.to_string());
                    }
                }
                // Otherwise run it (and let other queued tasks make progress first).
                self.run_task(id, &task)?;
                let st = task.borrow().state_clone();
                match st {
                    FutureState::Done(val) => Ok(val),
                    FutureState::Failed(e) => {
                        *self.pending_throw.borrow_mut() = Some(e);
                        Err(THROW_SENTINEL.to_string())
                    }
                    _ => Ok(Value::Null),
                }
            }
            // Awaiting a plain value is a no-op: it's already resolved.
            other => Ok(other),
        }
    }

    // Run a single spawned task body to completion, recording its result.
    fn run_task(&self, id: u64, task: &Rc<RefCell<TaskVal>>) -> Result<(), String> {
        let entry = self.task_bodies.borrow_mut().remove(&id);
        let (body, mut sc) = match entry {
            Some(x) => x,
            None => return Ok(()), // already consumed
        };
        task.borrow_mut().state = FutureState::Running;
        match self.run_async_body(&body, &mut sc) {
            Ok(val) => { task.borrow_mut().state = FutureState::Done(val); Ok(()) }
            Err(e) => {
                if e == THROW_SENTINEL {
                    let tv = self.pending_throw.borrow().clone().unwrap_or(Value::Null);
                    task.borrow_mut().state = FutureState::Failed(tv);
                    // a throw in a spawned task is contained: it surfaces only on await
                    return Ok(());
                }
                Err(e)
            }
        }
    }

    // Execute an async body (function/spawn) and extract its return value,
    // honoring `return`, implicit tail value, and throw.
    fn run_async_body(&self, body: &[Stmt], scope: &mut Scope) -> Result<Value, String> {
        match self.exec_block(body, scope)? {
            Flow::Return(v) => Ok(v),
            Flow::Break(v) => Ok(v),
            Flow::Continue => Ok(Value::Null),
            Flow::Throw(e) => {
                *self.pending_throw.borrow_mut() = Some(e);
                Err(THROW_SENTINEL.to_string())
            }
            Flow::Normal => Ok(Value::Null),
        }
    }

    // Receive one value from a channel. If empty, drive queued tasks (which may
    // produce a value via `ch <- v`), then retry; error if nothing ever arrives.
    fn channel_recv(&self, ch: Value) -> Result<Value, String> {
        let c = match ch {
            Value::Channel(c) => c,
            other => return Err(format!("recv expects a channel, got {}", other.type_name())),
        };
        // Fast path: a value is already buffered.
        if let Some(v) = c.borrow_mut().buffer.pop_front() {
            return Ok(v);
        }
        // Otherwise, let spawned tasks run to try to fill the channel.
        let mut guard = 0;
        loop {
            let next = self.ready_queue.borrow_mut().pop_front();
            match next {
                Some(task) => {
                    let id = task.borrow().id;
                    self.run_task(id, &task)?;
                }
                None => break,
            }
            if let Some(v) = c.borrow_mut().buffer.pop_front() {
                return Ok(v);
            }
            guard += 1;
            if guard > 1_000_000 { break; }
        }
        if let Some(v) = c.borrow_mut().buffer.pop_front() {
            return Ok(v);
        }
        if c.borrow().closed {
            return Ok(Value::Null);
        }
        *self.pending_throw.borrow_mut() =
            Some(Value::Str("receive on empty channel with no pending senders (deadlock)".into()));
        Err(THROW_SENTINEL.to_string())
    }

    // select { <- ch => body, ... }: pick the first arm whose channel has a value.
    // If none is ready, drive queued tasks once and retry, like channel_recv.
    fn eval_select(&self, arms: &[crate::ast::SelectArm], scope: &Scope) -> Result<Value, String> {
        let mut guard = 0;
        loop {
            // Evaluate each arm's channel and test readiness.
            for arm in arms {
                let chv = self.eval(&arm.chan, scope)?;
                if let Value::Channel(c) = &chv {
                    let ready = !c.borrow().buffer.is_empty();
                    if ready {
                        let v = c.borrow_mut().buffer.pop_front().unwrap();
                        let mut arm_scope = scope.clone();
                        if let Some(name) = &arm.binding {
                            arm_scope.insert(name.clone(), v);
                        } else {
                            arm_scope.insert("_recv".to_string(), v);
                        }
                        return self.eval(&arm.body, &arm_scope);
                    }
                }
            }
            // Nothing ready: run a queued task to make progress.
            let next = self.ready_queue.borrow_mut().pop_front();
            match next {
                Some(task) => {
                    let id = task.borrow().id;
                    self.run_task(id, &task)?;
                }
                None => {
                    *self.pending_throw.borrow_mut() =
                        Some(Value::Str("select: all channels empty and no tasks to run".into()));
                    return Err(THROW_SENTINEL.to_string());
                }
            }
            guard += 1;
            if guard > 1_000_000 {
                return Err("select: scheduler exceeded step budget".into());
            }
        }
    }
}

// Exact arithmetic/comparison on two BigInts (already coerced).
fn big_binop(op: BinOp, a: BigInt, b: BigInt) -> Result<Value, String> {
    use BinOp::*;
    use num_traits::Pow;
    let v = match op {
        Add => norm_big(a + b),
        Sub => norm_big(a - b),
        Mul => norm_big(a * b),
        Div => { if b.is_zero() { return Err("division by zero".into()); } norm_big(a / b) }
        Rem => { if b.is_zero() { return Err("modulo by zero".into()); } norm_big(a % b) }
        Pow => {
            if b.is_negative() {
                Value::Float(a.to_f64().unwrap_or(f64::NAN).powf(b.to_f64().unwrap_or(0.0)))
            } else {
                match b.to_u32() { Some(e) => norm_big(a.pow(e)), None => return Err("exponent too large".into()) }
            }
        }
        BitAnd => norm_big(a & b), BitOr => norm_big(a | b), BitXor => norm_big(a ^ b),
        Shl => { let s = b.to_u32().ok_or("shift too large")?; norm_big(a << s) }
        Shr => { let s = b.to_u32().ok_or("shift too large")?; norm_big(a >> s) }
        Eq => Value::Bool(a == b), Ne => Value::Bool(a != b),
        Lt => Value::Bool(a < b), Le => Value::Bool(a <= b),
        Gt => Value::Bool(a > b), Ge => Value::Bool(a >= b),
        And | Or => return Err("logical op on integers".into()),
    };
    Ok(v)
}

fn eval_binop(op: BinOp, l: Value, r: Value) -> Result<Value, String> {
    use Value::*;
    // BigInt path: if either side is a BigInt (or an Int that must promote),
    // do exact integer math. Floats still win when present (handled below).
    if matches!((&l, &r), (BigInt(_), _) | (_, BigInt(_)))
        && !matches!(&l, Float(_)) && !matches!(&r, Float(_)) {
        if let (Some(a), Some(b)) = (as_big(&l), as_big(&r)) {
            return big_binop(op, a, b);
        }
    }
    match (op, &l, &r) {
        // integer arithmetic — promote to BigInt on overflow
        (BinOp::Add, Int(a), Int(b)) => Ok(match a.checked_add(*b) {
            Some(v) => Int(v), None => norm_big(num_bigint::BigInt::from(*a) + num_bigint::BigInt::from(*b)),
        }),
        (BinOp::Sub, Int(a), Int(b)) => Ok(match a.checked_sub(*b) {
            Some(v) => Int(v), None => norm_big(num_bigint::BigInt::from(*a) - num_bigint::BigInt::from(*b)),
        }),
        (BinOp::Mul, Int(a), Int(b)) => Ok(match a.checked_mul(*b) {
            Some(v) => Int(v), None => norm_big(num_bigint::BigInt::from(*a) * num_bigint::BigInt::from(*b)),
        }),
        (BinOp::Div, Int(a), Int(b)) => {
            if *b == 0 { Err("division by zero".into()) } else { Ok(Int(a / b)) }
        }
        (BinOp::Rem, Int(a), Int(b)) => {
            if *b == 0 { Err("modulo by zero".into()) } else { Ok(Int(a % b)) }
        }
        (BinOp::Pow, Int(a), Int(b)) => {
            if *b < 0 {
                Ok(Float((*a as f64).powi(*b as i32)))
            } else if *b <= u32::MAX as i64 {
                match a.checked_pow(*b as u32) {
                    Some(v) => Ok(Int(v)),
                    None => {
                        use num_traits::Pow;
                        Ok(norm_big(num_bigint::BigInt::from(*a).pow(*b as u32)))
                    }
                }
            } else {
                Ok(Float((*a as f64).powf(*b as f64)))
            }
        }
        (BinOp::BitOr, Int(a), Int(b)) => Ok(Int(a | b)),
        (BinOp::BitXor, Int(a), Int(b)) => Ok(Int(a ^ b)),
        (BinOp::BitAnd, Int(a), Int(b)) => Ok(Int(a & b)),
        (BinOp::Shl, Int(a), Int(b)) => Ok(Int(a.wrapping_shl(*b as u32))),
        (BinOp::Shr, Int(a), Int(b)) => Ok(Int(a.wrapping_shr(*b as u32))),
        (BinOp::BitOr, _, _) | (BinOp::BitXor, _, _) | (BinOp::BitAnd, _, _)
        | (BinOp::Shl, _, _) | (BinOp::Shr, _, _) =>
            Err("bitwise operators require integer operands".into()),
        // float arithmetic (with int promotion)
        (BinOp::Add, _, _) if is_num(&l) && is_num(&r) => Ok(Float(as_f(&l) + as_f(&r))),
        (BinOp::Sub, _, _) if is_num(&l) && is_num(&r) => Ok(Float(as_f(&l) - as_f(&r))),
        (BinOp::Mul, _, _) if is_num(&l) && is_num(&r) => Ok(Float(as_f(&l) * as_f(&r))),
        (BinOp::Div, _, _) if is_num(&l) && is_num(&r) => Ok(Float(as_f(&l) / as_f(&r))),
        (BinOp::Rem, _, _) if is_num(&l) && is_num(&r) => Ok(Float(as_f(&l) % as_f(&r))),
        (BinOp::Pow, _, _) if is_num(&l) && is_num(&r) => Ok(Float(as_f(&l).powf(as_f(&r)))),
        // string concat
        (BinOp::Add, Str(a), Str(b)) => Ok(Str(format!("{}{}", a, b))),
        (BinOp::Add, Str(a), _) => Ok(Str(format!("{}{}", a, r))),
        (BinOp::Add, _, Str(b)) => Ok(Str(format!("{}{}", l, b))),
        // comparisons
        (BinOp::Eq, _, _) => Ok(Bool(values_eq(&l, &r))),
        (BinOp::Ne, _, _) => Ok(Bool(!values_eq(&l, &r))),
        (BinOp::Lt, _, _) if is_num(&l) && is_num(&r) => Ok(Bool(as_f(&l) < as_f(&r))),
        (BinOp::Le, _, _) if is_num(&l) && is_num(&r) => Ok(Bool(as_f(&l) <= as_f(&r))),
        (BinOp::Gt, _, _) if is_num(&l) && is_num(&r) => Ok(Bool(as_f(&l) > as_f(&r))),
        (BinOp::Ge, _, _) if is_num(&l) && is_num(&r) => Ok(Bool(as_f(&l) >= as_f(&r))),
        _ => Err(format!(
            "cannot apply {:?} to {} and {}",
            op, l.type_name(), r.type_name()
        )),
    }
}

fn is_known_module(name: &str) -> bool {
    matches!(name, "math" | "strings" | "arrays" | "collections" | "iter" | "rand" | "time" | "json" | "serialize" | "io" | "std")
}

// Dispatch a standard-library function by (optional module) + name.
// Returns Ok(Some(value)) if handled, Ok(None) if the name isn't a stdlib fn.
fn call_stdlib(name: &str, args: &[Value]) -> Result<Option<Value>, String> {
    // strip an optional module prefix: "math.sqrt" -> "sqrt"
    let short = name.rsplit('.').next().unwrap_or(name);
    let r = match short {
        // ---- math ----
        "pi" => Some(Value::Float(std::f64::consts::PI)),
        "e" => Some(Value::Float(std::f64::consts::E)),
        "sqrt" => Some(Value::Float(num_arg(args, 0, "sqrt")?.sqrt())),
        "abs" => {
            match args.get(0) {
                Some(Value::Int(n)) => Some(Value::Int(n.abs())),
                Some(Value::BigInt(b)) => Some(norm_big(b.abs())),
                Some(Value::Float(x)) => Some(Value::Float(x.abs())),
                _ => return Err("abs expects a number".into()),
            }
        }
        "pow" => {
            let b = num_arg(args, 0, "pow")?;
            let e = num_arg(args, 1, "pow")?;
            Some(Value::Float(b.powf(e)))
        }
        "floor" => Some(Value::Int(num_arg(args, 0, "floor")?.floor() as i64)),
        "ceil" => Some(Value::Int(num_arg(args, 0, "ceil")?.ceil() as i64)),
        "round" => Some(Value::Int(num_arg(args, 0, "round")?.round() as i64)),
        "sin" => Some(Value::Float(num_arg(args, 0, "sin")?.sin())),
        "cos" => Some(Value::Float(num_arg(args, 0, "cos")?.cos())),
        "tan" => Some(Value::Float(num_arg(args, 0, "tan")?.tan())),
        "log" => Some(Value::Float(num_arg(args, 0, "log")?.ln())),
        "log10" => Some(Value::Float(num_arg(args, 0, "log10")?.log10())),
        "exp" => Some(Value::Float(num_arg(args, 0, "exp")?.exp())),
        "min" => {
            let a = num_arg(args, 0, "min")?;
            let b = num_arg(args, 1, "min")?;
            Some(num_back(args, a.min(b)))
        }
        "max" => {
            let a = num_arg(args, 0, "max")?;
            let b = num_arg(args, 1, "max")?;
            Some(num_back(args, a.max(b)))
        }
        "gcd" => {
            let mut a = int_arg(args, 0, "gcd")?.abs();
            let mut b = int_arg(args, 1, "gcd")?.abs();
            while b != 0 { let t = b; b = a % b; a = t; }
            Some(Value::Int(a))
        }
        "lcm" => {
            let a = int_arg(args, 0, "lcm")?.abs();
            let b = int_arg(args, 1, "lcm")?.abs();
            if a == 0 || b == 0 { Some(Value::Int(0)) } else {
                let (mut x, mut y) = (a, b);
                while y != 0 { let t = y; y = x % y; x = t; }
                Some(Value::Int(a / x * b))
            }
        }
        "tau" => Some(Value::Float(std::f64::consts::TAU)),
        "phi" => Some(Value::Float(1.618_033_988_749_895_f64)),
        "cbrt" => Some(Value::Float(num_arg(args, 0, "cbrt")?.cbrt())),
        "sign" => {
            let n = num_arg(args, 0, "sign")?;
            Some(Value::Int(if n > 0.0 { 1 } else if n < 0.0 { -1 } else { 0 }))
        }
        "trunc" => Some(Value::Float(num_arg(args, 0, "trunc")?.trunc())),
        "fract" => Some(Value::Float(num_arg(args, 0, "fract")?.fract())),
        "hypot" => Some(Value::Float(num_arg(args, 0, "hypot")?.hypot(num_arg(args, 1, "hypot")?))),
        "clamp" => {
            let (x, lo, hi) = (num_arg(args, 0, "clamp")?, num_arg(args, 1, "clamp")?, num_arg(args, 2, "clamp")?);
            Some(Value::Float(x.max(lo).min(hi)))
        }
        "lerp" => {
            let (a, b, t) = (num_arg(args, 0, "lerp")?, num_arg(args, 1, "lerp")?, num_arg(args, 2, "lerp")?);
            Some(Value::Float(a + (b - a) * t))
        }
        "deg2rad" => Some(Value::Float(num_arg(args, 0, "deg2rad")?.to_radians())),
        "rad2deg" => Some(Value::Float(num_arg(args, 0, "rad2deg")?.to_degrees())),
        "asin" => Some(Value::Float(num_arg(args, 0, "asin")?.asin())),
        "acos" => Some(Value::Float(num_arg(args, 0, "acos")?.acos())),
        "atan" => Some(Value::Float(num_arg(args, 0, "atan")?.atan())),
        "atan2" => Some(Value::Float(num_arg(args, 0, "atan2")?.atan2(num_arg(args, 1, "atan2")?))),
        "sinh" => Some(Value::Float(num_arg(args, 0, "sinh")?.sinh())),
        "cosh" => Some(Value::Float(num_arg(args, 0, "cosh")?.cosh())),
        "tanh" => Some(Value::Float(num_arg(args, 0, "tanh")?.tanh())),
        "log2" => Some(Value::Float(num_arg(args, 0, "log2")?.log2())),
        "ln" => Some(Value::Float(num_arg(args, 0, "ln")?.ln())),
        "factorial" => {
            let n = int_arg(args, 0, "factorial")?;
            if n < 0 { return Err("factorial of negative number".into()); }
            let mut acc: i64 = 1;
            for i in 2..=n { acc = acc.saturating_mul(i); }
            Some(Value::Int(acc))
        }
        // ---- strings ----
        "upper" => Some(Value::Str(str_arg(args, 0, "upper")?.to_uppercase())),
        "lower" => Some(Value::Str(str_arg(args, 0, "lower")?.to_lowercase())),
        "trim" => Some(Value::Str(str_arg(args, 0, "trim")?.trim().to_string())),
        "split" => {
            let s = str_arg(args, 0, "split")?;
            let sep = str_arg(args, 1, "split")?;
            let parts: Vec<Value> = if sep.is_empty() {
                s.chars().map(|c| Value::Str(c.to_string())).collect()
            } else {
                s.split(&sep).map(|p| Value::Str(p.to_string())).collect()
            };
            Some(Value::Array(Rc::new(RefCell::new(parts))))
        }
        "join" => {
            let arr = match args.get(0) {
                Some(Value::Array(a)) => a.clone(),
                _ => return Err("join expects (array, separator)".into()),
            };
            let sep = str_arg(args, 1, "join")?;
            let joined = arr.borrow().iter().map(|v| v.to_string()).collect::<Vec<_>>().join(&sep);
            Some(Value::Str(joined))
        }
        "contains" => {
            let s = str_arg(args, 0, "contains")?;
            let sub = str_arg(args, 1, "contains")?;
            Some(Value::Bool(s.contains(&sub)))
        }
        "replace" => {
            let s = str_arg(args, 0, "replace")?;
            let from = str_arg(args, 1, "replace")?;
            let to = str_arg(args, 2, "replace")?;
            Some(Value::Str(s.replace(&from, &to)))
        }
        "starts_with" => {
            let s = str_arg(args, 0, "starts_with")?;
            let p = str_arg(args, 1, "starts_with")?;
            Some(Value::Bool(s.starts_with(&p)))
        }
        "ends_with" => {
            let s = str_arg(args, 0, "ends_with")?;
            let p = str_arg(args, 1, "ends_with")?;
            Some(Value::Bool(s.ends_with(&p)))
        }
        "trim_start" => Some(Value::Str(str_arg(args, 0, "trim_start")?.trim_start().to_string())),
        "trim_end" => Some(Value::Str(str_arg(args, 0, "trim_end")?.trim_end().to_string())),
        "repeat" => {
            let s = str_arg(args, 0, "repeat")?;
            let n = int_arg(args, 1, "repeat")?.max(0) as usize;
            Some(Value::Str(s.repeat(n)))
        }
        "reverse_str" => Some(Value::Str(str_arg(args, 0, "reverse_str")?.chars().rev().collect())),
        "capitalize" => {
            let s = str_arg(args, 0, "capitalize")?;
            let mut c = s.chars();
            Some(Value::Str(match c.next() {
                Some(f) => f.to_uppercase().collect::<String>() + &c.as_str().to_lowercase(),
                None => String::new(),
            }))
        }
        "title" => {
            let s = str_arg(args, 0, "title")?;
            let titled = s.split(' ').map(|w| {
                let mut c = w.chars();
                match c.next() {
                    Some(f) => f.to_uppercase().collect::<String>() + &c.as_str().to_lowercase(),
                    None => String::new(),
                }
            }).collect::<Vec<_>>().join(" ");
            Some(Value::Str(titled))
        }
        "pad_left" => {
            let s = str_arg(args, 0, "pad_left")?;
            let width = int_arg(args, 1, "pad_left")?.max(0) as usize;
            let pad = args.get(2).map(|v| v.to_string()).unwrap_or_else(|| " ".to_string());
            let pad_char = pad.chars().next().unwrap_or(' ');
            let cur = s.chars().count();
            Some(Value::Str(if cur >= width { s } else {
                pad_char.to_string().repeat(width - cur) + &s
            }))
        }
        "pad_right" => {
            let s = str_arg(args, 0, "pad_right")?;
            let width = int_arg(args, 1, "pad_right")?.max(0) as usize;
            let pad = args.get(2).map(|v| v.to_string()).unwrap_or_else(|| " ".to_string());
            let pad_char = pad.chars().next().unwrap_or(' ');
            let cur = s.chars().count();
            Some(Value::Str(if cur >= width { s } else {
                s + &pad_char.to_string().repeat(width - cur)
            }))
        }
        "find" => {
            let s = str_arg(args, 0, "find")?;
            let sub = str_arg(args, 1, "find")?;
            Some(match s.find(&sub) {
                Some(idx) => Value::Int(s[..idx].chars().count() as i64),
                None => Value::Int(-1),
            })
        }
        "substring" => {
            let s = str_arg(args, 0, "substring")?;
            let start = int_arg(args, 1, "substring")?.max(0) as usize;
            let chars: Vec<char> = s.chars().collect();
            let end = match args.get(2) {
                Some(Value::Int(e)) => (*e).max(0) as usize,
                _ => chars.len(),
            }.min(chars.len());
            let start = start.min(end);
            Some(Value::Str(chars[start..end].iter().collect()))
        }
        "levenshtein" => {
            let a = str_arg(args, 0, "levenshtein")?;
            let b = str_arg(args, 1, "levenshtein")?;
            let (ac, bc): (Vec<char>, Vec<char>) = (a.chars().collect(), b.chars().collect());
            let mut prev: Vec<usize> = (0..=bc.len()).collect();
            let mut cur = vec![0usize; bc.len() + 1];
            for i in 1..=ac.len() {
                cur[0] = i;
                for j in 1..=bc.len() {
                    let cost = if ac[i - 1] == bc[j - 1] { 0 } else { 1 };
                    cur[j] = (prev[j] + 1).min(cur[j - 1] + 1).min(prev[j - 1] + cost);
                }
                std::mem::swap(&mut prev, &mut cur);
            }
            Some(Value::Int(prev[bc.len()] as i64))
        }
        // ---- arrays / collections ----
        "sort" => {
            let arr = match args.get(0) {
                Some(Value::Array(a)) => a.clone(),
                _ => return Err("sort expects an array".into()),
            };
            let mut items = arr.borrow().clone();
            items.sort_by(|a, b| {
                let (x, y) = (as_f(a), as_f(b));
                x.partial_cmp(&y).unwrap_or(std::cmp::Ordering::Equal)
            });
            Some(Value::Array(Rc::new(RefCell::new(items))))
        }
        "reverse" => {
            let arr = match args.get(0) {
                Some(Value::Array(a)) => a.clone(),
                _ => return Err("reverse expects an array".into()),
            };
            let mut items = arr.borrow().clone();
            items.reverse();
            Some(Value::Array(Rc::new(RefCell::new(items))))
        }
        "sum" => {
            let arr = match args.get(0) {
                Some(Value::Array(a)) => a.clone(),
                _ => return Err("sum expects an array".into()),
            };
            let mut all_int = true;
            let mut acc = 0.0;
            for v in arr.borrow().iter() {
                match v {
                    Value::Int(n) => acc += *n as f64,
                    Value::Float(x) => { acc += x; all_int = false; }
                    other => return Err(format!("sum expects numbers, got {}", other.type_name())),
                }
            }
            Some(if all_int { Value::Int(acc as i64) } else { Value::Float(acc) })
        }
        "contains_elem" => {
            let arr = match args.get(0) {
                Some(Value::Array(a)) => a.clone(),
                _ => return Err("contains_elem expects (array, value)".into()),
            };
            let needle = args.get(1).ok_or("contains_elem expects (array, value)")?;
            let found = arr.borrow().iter().any(|v| values_eq(v, needle));
            Some(Value::Bool(found))
        }
        // ---- collections ----
        "first" => {
            let arr = expect_array(args.get(0), "first")?;
            let v = arr.borrow().first().cloned().unwrap_or(Value::Null);
            Some(v)
        }
        "last" => {
            let arr = expect_array(args.get(0), "last")?;
            let v = arr.borrow().last().cloned().unwrap_or(Value::Null);
            Some(v)
        }
        "min_of" => {
            let arr = expect_array(args.get(0), "min_of")?;
            let b = arr.borrow();
            if b.is_empty() { return Ok(Some(Value::Null)); }
            let mut m = b[0].clone();
            for v in b.iter().skip(1) {
                if value_lt(v, &m) { m = v.clone(); }
            }
            Some(m)
        }
        "max_of" => {
            let arr = expect_array(args.get(0), "max_of")?;
            let b = arr.borrow();
            if b.is_empty() { return Ok(Some(Value::Null)); }
            let mut m = b[0].clone();
            for v in b.iter().skip(1) {
                if value_lt(&m, v) { m = v.clone(); }
            }
            Some(m)
        }
        "unique" => {
            let arr = expect_array(args.get(0), "unique")?;
            let mut out: Vec<Value> = Vec::new();
            for v in arr.borrow().iter() {
                if !out.iter().any(|x| values_eq(x, v)) { out.push(v.clone()); }
            }
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "slice" => {
            let arr = expect_array(args.get(0), "slice")?;
            let start = int_arg(args, 1, "slice")?.max(0) as usize;
            let out: Vec<Value> = {
                let b = arr.borrow();
                let end = match args.get(2) {
                    Some(Value::Int(e)) => (*e).max(0) as usize,
                    _ => b.len(),
                }.min(b.len());
                let start = start.min(end);
                b[start..end].to_vec()
            };
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "take" => {
            let arr = expect_array(args.get(0), "take")?;
            let n = int_arg(args, 1, "take")?.max(0) as usize;
            let out: Vec<Value> = arr.borrow().iter().take(n).cloned().collect();
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "skip" => {
            let arr = expect_array(args.get(0), "skip")?;
            let n = int_arg(args, 1, "skip")?.max(0) as usize;
            let out: Vec<Value> = arr.borrow().iter().skip(n).cloned().collect();
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "flatten" => {
            let arr = expect_array(args.get(0), "flatten")?;
            let mut out: Vec<Value> = Vec::new();
            for v in arr.borrow().iter() {
                match v {
                    Value::Array(inner) => out.extend(inner.borrow().iter().cloned()),
                    other => out.push(other.clone()),
                }
            }
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "zip" => {
            let a = expect_array(args.get(0), "zip")?;
            let b = expect_array(args.get(1), "zip")?;
            let out: Vec<Value> = {
                let (ab, bb) = (a.borrow(), b.borrow());
                ab.iter().zip(bb.iter()).map(|(x, y)| {
                    Value::Array(Rc::new(RefCell::new(vec![x.clone(), y.clone()])))
                }).collect()
            };
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "enumerate" => {
            let arr = expect_array(args.get(0), "enumerate")?;
            let out: Vec<Value> = arr.borrow().iter().enumerate().map(|(i, v)| {
                Value::Array(Rc::new(RefCell::new(vec![Value::Int(i as i64), v.clone()])))
            }).collect();
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "chunk" => {
            let arr = expect_array(args.get(0), "chunk")?;
            let size = int_arg(args, 1, "chunk")?.max(1) as usize;
            let out: Vec<Value> = {
                let b = arr.borrow();
                b.chunks(size).map(|c| {
                    Value::Array(Rc::new(RefCell::new(c.to_vec())))
                }).collect()
            };
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        "concat" => {
            let a = expect_array(args.get(0), "concat")?;
            let b = expect_array(args.get(1), "concat")?;
            let mut out = a.borrow().clone();
            out.extend(b.borrow().iter().cloned());
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        // ---- iter ----
        "count" => {
            let arr = expect_array(args.get(0), "count")?;
            let n = arr.borrow().len() as i64;
            Some(Value::Int(n))
        }
        "position" => {
            let arr = expect_array(args.get(0), "position")?;
            let needle = args.get(1).ok_or("position expects (array, value)")?;
            let p = arr.borrow().iter().position(|v| values_eq(v, needle));
            Some(match p {
                Some(i) => Value::Int(i as i64),
                None => Value::Int(-1),
            })
        }
        "all_true" => {
            let arr = expect_array(args.get(0), "all_true")?;
            let r = arr.borrow().iter().all(|v| v.is_truthy());
            Some(Value::Bool(r))
        }
        "any_true" => {
            let arr = expect_array(args.get(0), "any_true")?;
            let r = arr.borrow().iter().any(|v| v.is_truthy());
            Some(Value::Bool(r))
        }
        // ---- rand ----
        "seed" => {
            let n = int_arg(args, 0, "seed")?;
            rng_seed(n as u64);
            Some(Value::Null)
        }
        "random" => Some(Value::Float(rng_float())),
        "rand_int" => {
            // rand_int(lo, hi) -> integer in [lo, hi] inclusive
            let lo = int_arg(args, 0, "rand_int")?;
            let hi = int_arg(args, 1, "rand_int")?;
            if hi < lo { return Err("rand_int: hi must be >= lo".into()); }
            let span = (hi - lo + 1) as u64;
            Some(Value::Int(lo + (rng_next() % span) as i64))
        }
        "rand_float" => {
            // rand_float(lo, hi) -> float in [lo, hi)
            let lo = num_arg(args, 0, "rand_float")?;
            let hi = num_arg(args, 1, "rand_float")?;
            Some(Value::Float(lo + rng_float() * (hi - lo)))
        }
        "rand_bool" => Some(Value::Bool(rng_next() & 1 == 1)),
        "choice" => {
            let arr = expect_array(args.get(0), "choice")?;
            let b = arr.borrow();
            if b.is_empty() { return Ok(Some(Value::Null)); }
            let idx = (rng_next() % b.len() as u64) as usize;
            Some(b[idx].clone())
        }
        "shuffle" => {
            // Fisher-Yates, returns a new shuffled array
            let arr = expect_array(args.get(0), "shuffle")?;
            let mut out = arr.borrow().clone();
            let n = out.len();
            for i in (1..n).rev() {
                let j = (rng_next() % (i as u64 + 1)) as usize;
                out.swap(i, j);
            }
            Some(Value::Array(Rc::new(RefCell::new(out))))
        }
        // ---- time ----
        "now" => {
            // unix timestamp in seconds (float, sub-second precision)
            let secs = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_secs_f64())
                .unwrap_or(0.0);
            Some(Value::Float(secs))
        }
        "now_millis" => {
            let ms = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_millis() as i64)
                .unwrap_or(0);
            Some(Value::Int(ms))
        }
        "now_nanos" => {
            let ns = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .map(|d| d.as_nanos() as i64)
                .unwrap_or(0);
            Some(Value::Int(ns))
        }
        // ---- json / serialize ----
        "json_parse" => {
            let s = str_arg(args, 0, "json_parse")?;
            Some(json_parse(&s)?)
        }
        "json_stringify" => {
            let v = args.get(0).ok_or("json_stringify expects a value")?;
            Some(Value::Str(json_stringify(v, false, 0)))
        }
        "json_pretty" => {
            let v = args.get(0).ok_or("json_pretty expects a value")?;
            Some(Value::Str(json_stringify(v, true, 0)))
        }
        _ => None,
    };
    Ok(r)
}

fn num_arg(args: &[Value], i: usize, f: &str) -> Result<f64, String> {
    match args.get(i) {
        Some(Value::Int(n)) => Ok(*n as f64),
        Some(Value::Float(x)) => Ok(*x),
        _ => Err(format!("{} expects a number at position {}", f, i + 1)),
    }
}
fn int_arg(args: &[Value], i: usize, f: &str) -> Result<i64, String> {
    match args.get(i) {
        Some(Value::Int(n)) => Ok(*n),
        _ => Err(format!("{} expects an integer at position {}", f, i + 1)),
    }
}
fn str_arg(args: &[Value], i: usize, f: &str) -> Result<String, String> {
    match args.get(i) {
        Some(Value::Str(s)) => Ok(s.clone()),
        _ => Err(format!("{} expects a string at position {}", f, i + 1)),
    }
}
// preserve int-ness for min/max when both inputs are ints
fn num_back(args: &[Value], result: f64) -> Value {
    let both_int = matches!(args.get(0), Some(Value::Int(_)))
        && matches!(args.get(1), Some(Value::Int(_)));
    if both_int { Value::Int(result as i64) } else { Value::Float(result) }
}

fn is_num(v: &Value) -> bool { matches!(v, Value::Int(_) | Value::Float(_) | Value::BigInt(_)) }
fn as_f(v: &Value) -> f64 {
    match v { Value::Int(n) => *n as f64, Value::Float(x) => *x,
              Value::BigInt(b) => b.to_f64().unwrap_or(f64::NAN), _ => 0.0 }
}
fn as_int(v: Option<&Value>) -> Result<i64, String> {
    match v {
        Some(Value::Int(n)) => Ok(*n),
        Some(other) => Err(format!("expected int, got {}", other.type_name())),
        None => Err("missing argument".into()),
    }
}
fn expect_array(v: Option<&Value>, fname: &str) -> Result<Rc<RefCell<Vec<Value>>>, String> {
    match v {
        Some(Value::Array(a)) => Ok(a.clone()),
        Some(other) => Err(format!("{} expects an array, got {}", fname, other.type_name())),
        None => Err(format!("{} missing array argument", fname)),
    }
}
fn expect_map(v: Option<&Value>, fname: &str) -> Result<Rc<RefCell<Vec<(Value, Value)>>>, String> {
    match v {
        Some(Value::Map(m)) => Ok(m.clone()),
        Some(other) => Err(format!("{} expects a map, got {}", fname, other.type_name())),
        None => Err(format!("{} missing map argument", fname)),
    }
}
fn value_lt(a: &Value, b: &Value) -> bool {
    use Value::*;
    match (a, b) {
        (Int(x), Int(y)) => x < y,
        (BigInt(x), BigInt(y)) => x < y,
        (BigInt(x), Int(y)) => *x < num_bigint::BigInt::from(*y),
        (Int(x), BigInt(y)) => num_bigint::BigInt::from(*x) < *y,
        (Float(x), Float(y)) => x < y,
        (Int(x), Float(y)) => (*x as f64) < *y,
        (Float(x), Int(y)) => *x < (*y as f64),
        (Str(x), Str(y)) => x < y,
        (Bool(x), Bool(y)) => !x & y,
        _ => false,
    }
}

fn values_eq(a: &Value, b: &Value) -> bool {
    use Value::*;
    match (a, b) {
        (Int(x), Int(y)) => x == y,
        (BigInt(x), BigInt(y)) => x == y,
        (BigInt(x), Int(y)) | (Int(y), BigInt(x)) => *x == num_bigint::BigInt::from(*y),
        (Float(x), Float(y)) => x == y,
        (Int(x), Float(y)) | (Float(y), Int(x)) => (*x as f64) == *y,
        (Str(x), Str(y)) => x == y,
        (Bool(x), Bool(y)) => x == y,
        (Null, Null) => true,
        (Array(x), Array(y)) => {
            let (xb, yb) = (x.borrow(), y.borrow());
            xb.len() == yb.len() && xb.iter().zip(yb.iter()).all(|(a, b)| values_eq(a, b))
        }
        (Struct(x), Struct(y)) => {
            // structural equality: same type and all fields equal
            let (xb, yb) = (x.borrow(), y.borrow());
            xb.type_name == yb.type_name
                && xb.fields.len() == yb.fields.len()
                && xb.fields.iter().all(|(k, v)| yb.fields.get(k).map_or(false, |w| values_eq(v, w)))
        }
        (Closure(x), Closure(y)) => Rc::ptr_eq(x, y),
        (Enum(x), Enum(y)) => {
            x.enum_name == y.enum_name
                && x.variant == y.variant
                && x.data.len() == y.data.len()
                && x.data.iter().zip(y.data.iter()).all(|(a, b)| values_eq(a, b))
        }
        (Map(x), Map(y)) => Rc::ptr_eq(x, y),
        _ => false,
    }
}

// ---- JSON: a real recursive-descent parser and serializer ----

struct JsonParser<'a> {
    chars: Vec<char>,
    pos: usize,
    _src: &'a str,
}

impl<'a> JsonParser<'a> {
    fn new(s: &'a str) -> Self {
        JsonParser { chars: s.chars().collect(), pos: 0, _src: s }
    }

    fn peek(&self) -> Option<char> {
        self.chars.get(self.pos).copied()
    }

    fn bump(&mut self) -> Option<char> {
        let c = self.chars.get(self.pos).copied();
        if c.is_some() { self.pos += 1; }
        c
    }

    fn skip_ws(&mut self) {
        while let Some(c) = self.peek() {
            if c == ' ' || c == '\t' || c == '\n' || c == '\r' { self.pos += 1; } else { break; }
        }
    }

    fn parse_value(&mut self) -> Result<Value, String> {
        self.skip_ws();
        match self.peek() {
            Some('{') => self.parse_object(),
            Some('[') => self.parse_array(),
            Some('"') => Ok(Value::Str(self.parse_string()?)),
            Some('t') | Some('f') => self.parse_bool(),
            Some('n') => self.parse_null(),
            Some(c) if c == '-' || c.is_ascii_digit() => self.parse_number(),
            Some(c) => Err(format!("unexpected character '{}' in JSON", c)),
            None => Err("unexpected end of JSON input".into()),
        }
    }

    fn parse_object(&mut self) -> Result<Value, String> {
        self.bump(); // consume '{'
        let mut pairs: Vec<(Value, Value)> = Vec::new();
        self.skip_ws();
        if self.peek() == Some('}') { self.bump(); return Ok(Value::Map(Rc::new(RefCell::new(pairs)))); }
        loop {
            self.skip_ws();
            if self.peek() != Some('"') { return Err("expected string key in JSON object".into()); }
            let key = self.parse_string()?;
            self.skip_ws();
            if self.bump() != Some(':') { return Err("expected ':' in JSON object".into()); }
            let val = self.parse_value()?;
            pairs.push((Value::Str(key), val));
            self.skip_ws();
            match self.bump() {
                Some(',') => continue,
                Some('}') => break,
                _ => return Err("expected ',' or '}' in JSON object".into()),
            }
        }
        Ok(Value::Map(Rc::new(RefCell::new(pairs))))
    }

    fn parse_array(&mut self) -> Result<Value, String> {
        self.bump(); // consume '['
        let mut items: Vec<Value> = Vec::new();
        self.skip_ws();
        if self.peek() == Some(']') { self.bump(); return Ok(Value::Array(Rc::new(RefCell::new(items)))); }
        loop {
            let v = self.parse_value()?;
            items.push(v);
            self.skip_ws();
            match self.bump() {
                Some(',') => continue,
                Some(']') => break,
                _ => return Err("expected ',' or ']' in JSON array".into()),
            }
        }
        Ok(Value::Array(Rc::new(RefCell::new(items))))
    }

    fn parse_string(&mut self) -> Result<String, String> {
        self.bump(); // consume opening quote
        let mut out = String::new();
        loop {
            match self.bump() {
                Some('"') => break,
                Some('\\') => match self.bump() {
                    Some('"') => out.push('"'),
                    Some('\\') => out.push('\\'),
                    Some('/') => out.push('/'),
                    Some('n') => out.push('\n'),
                    Some('t') => out.push('\t'),
                    Some('r') => out.push('\r'),
                    Some('b') => out.push('\u{0008}'),
                    Some('f') => out.push('\u{000C}'),
                    Some('u') => {
                        let mut code = 0u32;
                        for _ in 0..4 {
                            let c = self.bump().ok_or("incomplete \\u escape in JSON")?;
                            code = code * 16 + c.to_digit(16).ok_or("bad hex in \\u escape")?;
                        }
                        out.push(char::from_u32(code).unwrap_or('\u{FFFD}'));
                    }
                    _ => return Err("invalid escape in JSON string".into()),
                },
                Some(c) => out.push(c),
                None => return Err("unterminated JSON string".into()),
            }
        }
        Ok(out)
    }

    fn parse_number(&mut self) -> Result<Value, String> {
        let start = self.pos;
        let mut is_float = false;
        if self.peek() == Some('-') { self.bump(); }
        while let Some(c) = self.peek() {
            if c.is_ascii_digit() { self.bump(); }
            else if c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-' { is_float = true; self.bump(); }
            else { break; }
        }
        let text: String = self.chars[start..self.pos].iter().collect();
        if is_float {
            text.parse::<f64>().map(Value::Float).map_err(|_| format!("bad JSON number: {}", text))
        } else {
            match text.parse::<i64>() {
                Ok(n) => Ok(Value::Int(n)),
                Err(_) => text.parse::<f64>().map(Value::Float).map_err(|_| format!("bad JSON number: {}", text)),
            }
        }
    }

    fn parse_bool(&mut self) -> Result<Value, String> {
        if self.chars[self.pos..].starts_with(&['t','r','u','e']) {
            self.pos += 4; Ok(Value::Bool(true))
        } else if self.chars[self.pos..].starts_with(&['f','a','l','s','e']) {
            self.pos += 5; Ok(Value::Bool(false))
        } else {
            Err("invalid JSON literal".into())
        }
    }

    fn parse_null(&mut self) -> Result<Value, String> {
        if self.chars[self.pos..].starts_with(&['n','u','l','l']) {
            self.pos += 4; Ok(Value::Null)
        } else {
            Err("invalid JSON literal".into())
        }
    }
}

fn json_parse(s: &str) -> Result<Value, String> {
    let mut p = JsonParser::new(s);
    let v = p.parse_value()?;
    p.skip_ws();
    if p.pos != p.chars.len() {
        return Err("trailing characters after JSON value".into());
    }
    Ok(v)
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            '\u{0008}' => out.push_str("\\b"),
            '\u{000C}' => out.push_str("\\f"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

fn json_stringify(v: &Value, pretty: bool, indent: usize) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Int(n) => n.to_string(),
        Value::Float(f) => f.to_string(),
        Value::Str(s) => json_escape(s),
        Value::Array(a) => {
            let b = a.borrow();
            if b.is_empty() { return "[]".to_string(); }
            if pretty {
                let pad = "  ".repeat(indent + 1);
                let close = "  ".repeat(indent);
                let items: Vec<String> = b.iter().map(|x| format!("{}{}", pad, json_stringify(x, true, indent + 1))).collect();
                format!("[\n{}\n{}]", items.join(",\n"), close)
            } else {
                let items: Vec<String> = b.iter().map(|x| json_stringify(x, false, 0)).collect();
                format!("[{}]", items.join(","))
            }
        }
        Value::Map(m) => {
            let b = m.borrow();
            if b.is_empty() { return "{}".to_string(); }
            if pretty {
                let pad = "  ".repeat(indent + 1);
                let close = "  ".repeat(indent);
                let items: Vec<String> = b.iter().map(|(k, val)| {
                    format!("{}{}: {}", pad, json_escape(&k.to_string()), json_stringify(val, true, indent + 1))
                }).collect();
                format!("{{\n{}\n{}}}", items.join(",\n"), close)
            } else {
                let items: Vec<String> = b.iter().map(|(k, val)| {
                    format!("{}:{}", json_escape(&k.to_string()), json_stringify(val, false, 0))
                }).collect();
                format!("{{{}}}", items.join(","))
            }
        }
        _ => "null".to_string(),
    }
}
